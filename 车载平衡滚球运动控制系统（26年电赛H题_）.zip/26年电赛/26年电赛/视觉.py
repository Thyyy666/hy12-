import gc
import os
import sys
import time
from libs.PipeLine import PipeLine
from libs.YOLO import YOLO11
from media.sensor import *

try:
    from machine import UART
    from machine import FPIOA
    from machine import Pin
except BaseException:
    UART = None
    FPIOA = None
    Pin = None


kmodel_path = "/sdcard/yolo11n_det_320.kmodel"
labels = {0: "ball"}
model_input_size = [320, 320]
confidence_threshold = 0.07
nms_threshold = 0.95
serial_baudrate = 115200
scale_factor = 4.0 / 3.0

deadzone_units = 1.0
deadzone_hold_ms = 500
away_brake_speed_threshold = 0.8
away_brake_output_level = 15
away_brake_zero_hold_ms = 100
track_jump_limit_ratio = 0.125
target_tolerance = 0.35
k1_switch_tolerance_units = 0.6
k1_finish_t_tolerance_units = 1.0
control_level_4_zone_units = 1.0
control_level_3_zone_units = 1.8125
control_level_2_zone_units = 4.375
control_accel_level_4 = 0.25
control_accel_level_3 = 0.5
control_accel_level_2 = 1.0
control_accel_level_1 = 1.5
brake_inner_zone_units = 1.8
brake_factor_inner = 0.03
brake_factor_outer = 0.055
center_brake_factor_inner = 0.06
center_brake_factor_outer = 0.11
k1_positive_brake_factor_inner = 0.03
k1_positive_brake_factor = 0.055
mode_d_settle_ms = 5000
mode_e_delay_ms = 800
mode_e_buffer_ms = 1500
mode_e_forward_stop_units = 0.5
mode_e_output_start = 9
mode_e_output_end = 8
mode_f_output_start = -12
mode_f_output_end = -8
gc_collect_interval_frames = 30
camera_retry_limit = 3

DISPLAY_WIDTH = 640
DISPLAY_HEIGHT = 480
Y_CENTER_TOLERANCE_PX = 40
SHOW_TO_IDE = False
IDE_QUALITY = 50

DETECT_WIDTH = 320
DETECT_HEIGHT = 240
rgb888p_size = [DETECT_WIDTH, DETECT_HEIGHT]

display_size = [DISPLAY_WIDTH, DISPLAY_HEIGHT]
display_mode = "lcd"


def try_sensor_call(sensor, method_names, *args):
    for method_name in method_names:
        if not hasattr(sensor, method_name):
            continue
        try:
            getattr(sensor, method_name)(*args)
            return method_name, True, None
        except BaseException as e:
            return method_name, False, e
    return None, False, None


def configure_sensor(sensor):
    config_items = (
        ("auto exposure", ("auto_exposure", "set_auto_exposure"), (False,)),
        ("auto white balance", ("auto_whitebal", "set_auto_whitebal"), (False,)),
        ("auto gain", ("auto_gain", "set_auto_gain"), (False,)),
    )

    for label, method_names, args in config_items:
        method_name, ok, err = try_sensor_call(sensor, method_names, *args)
        if method_name is None:
            print(label + " control not exposed by current firmware")
        elif ok:
            print(label + ": off")
        else:
            print(label + " off failed:", err)


def init_port1_uart():
    if UART is None or FPIOA is None:
        print("PORT1 UART not available")
        return None
    try:
        fpioa = FPIOA()
        fpioa.set_function(40, FPIOA.UART1_TXD)
        fpioa.set_function(41, FPIOA.UART1_RXD)
        uart = UART(
            UART.UART1,
            baudrate=serial_baudrate,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE,
        )
        print("PORT1 UART: UART1 IO40/IO41", serial_baudrate)
        return uart
    except BaseException as e:
        print("PORT1 UART init failed:", e)
        return None


def init_button(name, pin_id, gpio_func, pull=None):
    if Pin is None or FPIOA is None or gpio_func is None:
        print(name + " button not available")
        return None
    try:
        if pull is None:
            pull = Pin.PULL_UP
        fpioa = FPIOA()
        fpioa.set_function(pin_id, gpio_func)
        key = Pin(pin_id, Pin.IN, pull=pull, drive=7)
        print(name + " button: IO" + str(pin_id))
        return key
    except BaseException as e:
        print(name + " button init failed:", e)
        return None


def button_pressed(key, active_value=0):
    if key is None:
        return False
    try:
        return key.value() == active_value
    except BaseException:
        return False


def send_port1_value(uart, value):
    if uart is None:
        return 0
    try:
        uart.write("{}\n".format(value))
        return 1
    except BaseException as e:
        print("PORT1 UART write failed:", e)
        return -1


def uart_data_to_text(data):
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    try:
        return data.decode()
    except BaseException:
        return str(data)


def mode_command_from_text(text):
    command = None
    for ch in text:
        if ch == "A" or ch == "a":
            command = 0
        elif ch == "C" or ch == "c":
            command = 1
        elif ch == "D" or ch == "d":
            command = 2
        elif ch == "E" or ch == "e":
            command = 3
        elif ch == "F" or ch == "f":
            command = 4
    return command


def read_port1_rx(uart, rx_buffer):
    if uart is None:
        return 0, rx_buffer, "", None
    try:
        if not hasattr(uart, "read"):
            return -1, rx_buffer, "", None
        count = 0
        if hasattr(uart, "any"):
            count = uart.any()
            if count is None or count <= 0:
                return 0, rx_buffer, "", None
            data = uart.read(count)
        else:
            data = uart.read()
        if data is None:
            return 0, rx_buffer, "", None
        text = uart_data_to_text(data)
        if text == "":
            return 0, rx_buffer, "", None

        mode_command = mode_command_from_text(text)

        rx_buffer += text
        if len(rx_buffer) > 80:
            rx_buffer = rx_buffer[-80:]

        last_line = ""
        while "\n" in rx_buffer:
            parts = rx_buffer.split("\n", 1)
            line = parts[0].strip()
            rx_buffer = parts[1]
            if line != "":
                last_line = line

        if last_line != "":
            return 1, rx_buffer, last_line, mode_command
        if mode_command is not None:
            return 1, rx_buffer, text.strip(), mode_command
        return 1, rx_buffer, text.strip(), None
    except BaseException as e:
        print("PORT1 UART read failed:", e)
        return -1, rx_buffer, "", None


def draw_text_safe(img, x, y, text, color):
    if hasattr(img, "draw_string_advanced"):
        try:
            img.draw_string_advanced(x, y, 24, text, color)
            return
        except BaseException:
            pass
    if hasattr(img, "draw_string"):
        try:
            img.draw_string(x, y, text, color=color)
        except BaseException:
            pass


def position_unit_px():
    return (DISPLAY_WIDTH / 20.0) * scale_factor


def speed_unit_px():
    return (DISPLAY_WIDTH / 40.0) * scale_factor


def scaled_guide_offset_px(base_offset_px):
    return base_offset_px * scale_factor


def draw_guides(img):
    if not hasattr(img, "draw_line"):
        return

    width = DISPLAY_WIDTH
    height = DISPLAY_HEIGHT
    center_x = width // 2
    step = width / 20.0
    green = (255, 0, 255, 0)
    dark_green = (255, 0, 160, 0)
    yellow = (255, 255, 255, 0)

    guide_lines = (
        (scaled_guide_offset_px(2.0 * step - width / 100.0), "2cm"),
        (scaled_guide_offset_px(4.0 * step + width / 50.0), "5cm"),
        (scaled_guide_offset_px(8.0 * step), "10cm"),
    )

    try:
        img.draw_line(center_x, 0, center_x, height - 1, color=green, thickness=3)
        img.draw_line(center_x - 8, height // 2, center_x + 8, height // 2, color=green, thickness=3)
    except BaseException:
        return

    draw_text_safe(img, center_x - 12, 8, "0", green)

    for offset, label in guide_lines:
        left_x = int(center_x - offset)
        right_x = int(center_x + offset)
        if left_x >= 0:
            try:
                img.draw_line(left_x, 0, left_x, height - 1, color=dark_green, thickness=1)
                draw_text_safe(img, max(0, left_x - 18), 8, label, dark_green)
            except BaseException:
                pass
        if right_x < width:
            try:
                img.draw_line(right_x, 0, right_x, height - 1, color=dark_green, thickness=1)
                draw_text_safe(img, min(width - 52, right_x + 4), 8, label, dark_green)
            except BaseException:
                pass

    if hasattr(img, "draw_rectangle"):
        box_w = max(1, width * 9 // 10)
        box_x = (width - box_w) // 2
        box_h = max(1, height // 4)
        box_y = (height - box_h) // 2
        try:
            img.draw_rectangle(box_x, box_y, box_w, box_h, color=yellow, thickness=2)
        except BaseException:
            pass


def draw_target_center_line(img, target_units):
    if target_units is None or not hasattr(img, "draw_line"):
        return
    x = int(clamp(DISPLAY_WIDTH / 2.0 + target_units * position_unit_px(), 0, DISPLAY_WIDTH - 1))
    red = (255, 255, 0, 0)
    try:
        img.draw_line(x, 0, x, DISPLAY_HEIGHT - 1, color=red, thickness=3)
    except BaseException:
        pass


class DrawCapture:
    def __init__(self):
        self.boxes = []

    def clear(self):
        del self.boxes[:]

    def draw_rectangle(self, x, y, w, h, *args, **kwargs):
        x = int(x)
        y = int(y)
        w = int(w)
        h = int(h)
        if w > 0 and h > 0:
            self.boxes.append((x, y, x + w, y + h))

    def draw_string(self, *args, **kwargs):
        pass

    def draw_string_advanced(self, *args, **kwargs):
        pass

    def draw_text(self, *args, **kwargs):
        pass


def clamp(value, low, high):
    if value < low:
        return low
    if value > high:
        return high
    return value


def now_ms():
    if hasattr(time, "ticks_ms"):
        return time.ticks_ms()
    return int(time.time() * 1000)


def diff_ms(current_ms, previous_ms):
    if previous_ms is None:
        return 0
    if hasattr(time, "ticks_diff"):
        return time.ticks_diff(current_ms, previous_ms)
    return current_ms - previous_ms


def add_ms(base_ms, delta_ms):
    if hasattr(time, "ticks_add"):
        return time.ticks_add(base_ms, delta_ms)
    return base_ms + delta_ms


def box_center(box):
    x1, y1, x2, y2 = box
    return (x1 + x2) / 2.0, (y1 + y2) / 2.0


def match_previous_track(center, previous_tracks, used_indices):
    best_index = None
    best_distance = None
    jump_limit = DISPLAY_WIDTH * track_jump_limit_ratio
    jump_limit_sq = jump_limit * jump_limit
    for index, previous_track in enumerate(previous_tracks):
        if index in used_indices:
            continue
        previous_center = previous_track["center"]
        dx = center[0] - previous_center[0]
        dy = center[1] - previous_center[1]
        distance = dx * dx + dy * dy
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best_index = index
    if best_index is None:
        return None
    if best_distance is not None and best_distance > jump_limit_sq:
        return None
    used_indices.append(best_index)
    return previous_tracks[best_index]


def calc_position_level(center_x):
    unit = position_unit_px()
    dx = center_x - DISPLAY_WIDTH / 2.0
    if abs(dx) <= unit:
        return 0
    level = int(abs(dx) / unit)
    level = clamp(level, 1, 10)
    if dx < 0:
        level = -level
    return level


def calc_position_units(center_x):
    return (center_x - DISPLAY_WIDTH / 2.0) / position_unit_px()


def calc_speed_units(center_x, previous_center_x, dt_ms):
    if previous_center_x is None or dt_ms <= 0:
        return 0.0
    vx_px_s = (center_x - previous_center_x) * 1000.0 / dt_ms
    return vx_px_s / speed_unit_px()


def sign(value):
    if value > 0:
        return 1
    if value < 0:
        return -1
    return 0


def target_5cm_units():
    step = DISPLAY_WIDTH / 20.0
    offset = scaled_guide_offset_px(4.0 * step + DISPLAY_WIDTH / 50.0)
    return offset / position_unit_px()


def target_units_for_mode(active_mode, mode1, mode_d, mode_e):
    if active_mode == 0:
        return 0.0
    if active_mode == 1:
        positive_target = target_5cm_units()
        if mode1.get("phase", 0) == 1:
            return -positive_target
        return positive_target
    if active_mode == 2:
        if mode_d.get("phase", 0) == 1:
            return mode_d.get("target_units", 0.0)
        return None
    if active_mode == 3:
        paused_mode = mode_e.get("paused_mode", -1)
        return target_units_for_mode(
            paused_mode,
            mode_e.get("paused_mode1", {"phase": 0}),
            mode_e.get("paused_mode_d", start_mode_d(0)),
            {"paused_mode": -1},
        )
    return None


def reset_deadzone(deadzone):
    deadzone["start_ms"] = None
    deadzone["target"] = None


def reset_away_brake(away_brake):
    away_brake["active"] = False
    away_brake["target"] = None
    away_brake["output"] = 0
    away_brake["zero_start_ms"] = None


def update_deadzone(deadzone, active_mode, target_units, ball_state, output_value, mode_status, current_ms):
    if active_mode not in (0, 1, 2) or target_units is None or ball_state is None:
        reset_deadzone(deadzone)
        return output_value, mode_status

    previous_target = deadzone.get("target", None)
    if previous_target is None or abs(previous_target - target_units) > 0.01:
        reset_deadzone(deadzone)
        deadzone["target"] = target_units

    if abs(ball_state["x_units"] - target_units) <= deadzone_units:
        if deadzone.get("start_ms", None) is None:
            deadzone["start_ms"] = current_ms
    else:
        reset_deadzone(deadzone)

    start_ms = deadzone.get("start_ms", None)
    if start_ms is not None:
        hold_ms = diff_ms(current_ms, start_ms)
        if hold_ms >= deadzone_hold_ms:
            speed_sign = sign(ball_state["speed_units"])
            output_sign = sign(output_value)
            if speed_sign != 0 and output_sign == -speed_sign:
                return output_value, "{} DZB:{}ms".format(mode_status, hold_ms)
            return 0, "{} DZ:{}ms".format(mode_status, hold_ms)
    return output_value, mode_status


def update_away_brake(away_brake, active_mode, target_units, ball_state, output_value, mode_status, current_ms):
    if active_mode not in (0, 1, 2) or target_units is None or ball_state is None:
        reset_away_brake(away_brake)
        return output_value, mode_status

    previous_target = away_brake.get("target", None)
    if previous_target is None or abs(previous_target - target_units) > 0.01:
        reset_away_brake(away_brake)
        away_brake["target"] = target_units

    speed_units = ball_state["speed_units"]
    abs_speed = abs(speed_units)
    speed_dir = sign(speed_units)

    zero_start_ms = away_brake.get("zero_start_ms", None)
    if zero_start_ms is not None:
        zero_elapsed_ms = diff_ms(current_ms, zero_start_ms)
        if zero_elapsed_ms < away_brake_zero_hold_ms:
            return 0, "{} EB0:{}ms".format(mode_status, zero_elapsed_ms)
        away_brake["zero_start_ms"] = None

    if away_brake.get("active", False):
        if abs_speed < away_brake_speed_threshold:
            away_brake["active"] = False
            away_brake["output"] = 0
            away_brake["zero_start_ms"] = current_ms
            return 0, "{} EB0:0ms".format(mode_status)
        if speed_dir != 0:
            away_brake["output"] = -speed_dir * away_brake_output_level
        return away_brake.get("output", output_value), "{} EB:{:.1f}".format(mode_status, abs_speed)

    error = target_units - ball_state["x_units"]
    moving_away_from_target = error * speed_units < 0
    if moving_away_from_target and abs_speed > away_brake_speed_threshold and speed_dir != 0:
        away_brake["active"] = True
        away_brake["target"] = target_units
        away_brake["output"] = -speed_dir * away_brake_output_level
        return away_brake["output"], "{} EB:{:.1f}".format(mode_status, abs_speed)

    return output_value, mode_status


def control_level_for_distance(distance_units):
    if distance_units <= control_level_4_zone_units:
        return 4
    if distance_units <= control_level_3_zone_units:
        return 3
    if distance_units <= control_level_2_zone_units:
        return 2
    return 1


def brake_factor_for_distance(distance_units):
    if distance_units <= brake_inner_zone_units:
        return brake_factor_inner
    return brake_factor_outer


def center_brake_factor_for_distance(distance_units):
    if distance_units <= brake_inner_zone_units:
        return center_brake_factor_inner
    return center_brake_factor_outer


def k1_positive_brake_factor_for_distance(distance_units):
    if distance_units <= brake_inner_zone_units:
        return k1_positive_brake_factor_inner
    return k1_positive_brake_factor


def estimate_stop_distance_units(abs_speed_units, abs_error_units):
    speed_sq = abs_speed_units * abs_speed_units
    current_distance = abs_error_units
    stop_distance = 0.0

    while current_distance > 0 and speed_sq > 0:
        if current_distance > control_level_2_zone_units:
            accel = control_accel_level_1
            next_distance = control_level_2_zone_units
        elif current_distance > control_level_3_zone_units:
            accel = control_accel_level_2
            next_distance = control_level_3_zone_units
        elif current_distance > control_level_4_zone_units:
            accel = control_accel_level_3
            next_distance = control_level_4_zone_units
        else:
            accel = control_accel_level_4
            next_distance = 0.0

        segment_distance = current_distance - next_distance
        segment_stop_distance = speed_sq / (4.0 * accel)
        if segment_stop_distance <= segment_distance:
            return stop_distance + segment_stop_distance

        speed_sq -= 4.0 * accel * segment_distance
        stop_distance += segment_distance
        current_distance = next_distance

    if speed_sq <= 0:
        return stop_distance
    return stop_distance + speed_sq / (4.0 * control_accel_level_4)


def compute_brake_output(x_units, speed_units, target_units, brake_factor_override=None):
    error = target_units - x_units
    abs_error = abs(error)
    abs_speed = abs(speed_units)

    level = control_level_for_distance(abs_error)

    if abs_error <= target_tolerance:
        return -sign(speed_units) * level, 0.0

    moving_toward_target = error * speed_units > 0
    stop_distance = estimate_stop_distance_units(abs_speed, abs_error)
    if brake_factor_override is None:
        brake_factor = brake_factor_for_distance(abs_error)
    else:
        brake_factor = brake_factor_override
    brake_distance = stop_distance * brake_factor
    if moving_toward_target and brake_distance >= max(0.0, abs_error - target_tolerance):
        return -sign(speed_units) * level, brake_distance

    return sign(error) * level, brake_distance


def update_mode1(mode1, ball_state):
    if ball_state is None:
        return 0, "NO BALL"

    positive_target = target_5cm_units()
    phase = mode1.get("phase", 0)
    if phase == 0 and abs(ball_state["x_units"] - positive_target) <= k1_switch_tolerance_units:
        phase = 1
        mode1["phase"] = 1

    if phase == 1:
        target_units = -positive_target
        target_name = "-5cm"
        brake_factor_override = None
    else:
        target_units = positive_target
        target_name = "+5cm"
        brake_factor_override = k1_positive_brake_factor_for_distance(
            abs(target_units - ball_state["x_units"])
        )

    output_value, stop_distance = compute_brake_output(
        ball_state["x_units"],
        ball_state["speed_units"],
        target_units,
        brake_factor_override,
    )
    if brake_factor_override is None:
        active_brake_factor = brake_factor_for_distance(abs(target_units - ball_state["x_units"]))
    else:
        active_brake_factor = brake_factor_override

    status = "{} P:{} A:{} S:{:.1f} B:{:.2f}".format(
        target_name,
        phase,
        output_value,
        stop_distance,
        active_brake_factor,
    )
    return output_value, status


def k1_finish_t_ready(mode1, ball_state):
    if mode1.get("phase", 0) != 1 or mode1.get("t_sent", False):
        return False
    if ball_state is None:
        return False
    negative_target = -target_5cm_units()
    return abs(ball_state["x_units"] - negative_target) <= k1_finish_t_tolerance_units


def update_center_mode(ball_state, target_units, target_name, brake_factor_func=None):
    if ball_state is None:
        return 0, "NO BALL"
    abs_error = abs(target_units - ball_state["x_units"])
    if brake_factor_func is None:
        active_brake_factor = brake_factor_for_distance(abs_error)
    else:
        active_brake_factor = brake_factor_func(abs_error)
    output_value, stop_distance = compute_brake_output(
        ball_state["x_units"],
        ball_state["speed_units"],
        target_units,
        active_brake_factor,
    )
    return output_value, "{} A:{} S:{:.1f} B:{:.2f} T:{:.2f}".format(
        target_name,
        output_value,
        stop_distance,
        active_brake_factor,
        target_units,
    )


def update_mode0(ball_state):
    return update_center_mode(ball_state, 0.0, "CENTER", center_brake_factor_for_distance)


def copy_state_dict(state):
    copied = {}
    for key in state:
        copied[key] = state[key]
    return copied


def start_mode_d(start_ms):
    return {"phase": 0, "start_ms": start_ms, "target_units": 0.0}


def update_mode_d(mode_d, ball_state, current_ms):
    phase = mode_d.get("phase", 0)
    if phase == 0:
        elapsed_ms = diff_ms(current_ms, mode_d.get("start_ms", current_ms))
        if elapsed_ms < mode_d_settle_ms:
            return 0, "WAIT {}ms".format(elapsed_ms)
        if ball_state is None:
            return 0, "WAIT NO BALL"
        mode_d["target_units"] = ball_state["x_units"]
        mode_d["phase"] = 1
        print("PORT1 CMD D: CENTER {:.2f}".format(mode_d["target_units"]))
    return update_center_mode(ball_state, mode_d.get("target_units", 0.0), "DCENTER")


def start_mode_e(start_ms, paused_mode, paused_mode1, paused_mode_d, output_start, output_end, label):
    return {
        "start_ms": start_ms,
        "paused_mode": paused_mode,
        "paused_mode1": copy_state_dict(paused_mode1),
        "paused_mode_d": copy_state_dict(paused_mode_d),
        "output_start": output_start,
        "output_end": output_end,
        "label": label,
        "forward_start_x": None,
        "forward_started": False,
    }


def mode_e_forward_stop_done(mode_e, ball_state, current_ms):
    if mode_e.get("label", "E") != "E":
        return False
    elapsed_ms = diff_ms(current_ms, mode_e.get("start_ms", current_ms))
    if elapsed_ms < mode_e_delay_ms:
        mode_e["forward_start_x"] = None
        mode_e["forward_started"] = False
        return False
    if ball_state is None:
        return False

    x_units = ball_state["x_units"]
    speed_units = ball_state["speed_units"]
    if mode_e.get("forward_start_x", None) is None:
        mode_e["forward_start_x"] = x_units
        mode_e["forward_started"] = False
        return False

    if speed_units > 0:
        mode_e["forward_started"] = True

    moved_units = x_units - mode_e.get("forward_start_x", x_units)
    return mode_e.get("forward_started", False) and moved_units >= mode_e_forward_stop_units


def mode_e_buffer_done(mode_e, current_ms, ball_state):
    if mode_e_forward_stop_done(mode_e, ball_state, current_ms):
        return True
    elapsed_ms = diff_ms(current_ms, mode_e.get("start_ms", current_ms))
    return elapsed_ms >= mode_e_delay_ms + mode_e_buffer_ms


def mode_e_buffer_output(mode_e, current_ms):
    if mode_e_buffer_ms <= 0:
        return mode_e.get("output_end", mode_e_output_end), "BUF 0ms"
    elapsed_ms = diff_ms(current_ms, mode_e.get("start_ms", current_ms))
    if elapsed_ms < mode_e_delay_ms:
        return 0, "DELAY {}ms".format(elapsed_ms)
    buffer_elapsed_ms = elapsed_ms - mode_e_delay_ms
    progress = buffer_elapsed_ms / float(mode_e_buffer_ms)
    progress = clamp(progress, 0.0, 1.0)
    output_start = mode_e.get("output_start", mode_e_output_start)
    output_end = mode_e.get("output_end", mode_e_output_end)
    direction = 1 if output_end >= output_start else -1
    level_count = abs(output_end - output_start) + 1
    level_index = int(progress * level_count)
    if level_index >= level_count:
        level_index = level_count - 1
    output_value = output_start + direction * level_index
    return output_value, "BUF {}ms".format(buffer_elapsed_ms)


def restore_mode_e(mode_e, current_ms):
    paused_mode = mode_e.get("paused_mode", -1)
    paused_mode1 = copy_state_dict(mode_e.get("paused_mode1", {"phase": 0}))
    paused_mode_d = copy_state_dict(mode_e.get("paused_mode_d", start_mode_d(current_ms)))
    pause_ms = diff_ms(current_ms, mode_e.get("start_ms", current_ms))
    if paused_mode == 2 and paused_mode_d.get("phase", 0) == 0:
        paused_mode_d["start_ms"] = add_ms(paused_mode_d.get("start_ms", current_ms), pause_ms)
    return paused_mode, paused_mode1, paused_mode_d


def draw_mode_status(img, mode_name, status, output_value):
    text = "{} {} OUT:{}".format(mode_name, status, output_value)
    draw_text_safe(img, 8, DISPLAY_HEIGHT - 28, text, (255, 255, 255, 0))


def draw_brake_factor(img):
    text = "B:{:.2f}/{:.2f}".format(brake_factor_inner, brake_factor_outer)
    draw_text_safe(img, DISPLAY_WIDTH - 150, DISPLAY_HEIGHT - 28, text, (255, 0, 255, 0))


def draw_uart_status(img, tx_state, tx_value, tx_count, rx_state, rx_text, rx_count):
    if tx_state > 0:
        tx_status = "TX OK"
        tx_color = (255, 0, 255, 0)
    elif tx_state < 0:
        tx_status = "TX ERR"
        tx_color = (255, 255, 0, 0)
    else:
        tx_status = "TX OFF"
        tx_color = (255, 255, 255, 0)

    if rx_state > 0:
        rx_status = "RX OK"
        rx_color = (255, 0, 255, 0)
    elif rx_state < 0:
        rx_status = "RX ERR"
        rx_color = (255, 255, 0, 0)
    else:
        rx_status = "RX WAIT"
        rx_color = (255, 255, 255, 0)

    tx_text = "{} V:{} N:{}".format(tx_status, tx_value, tx_count)
    rx_text = "{} V:{} N:{}".format(rx_status, rx_text, rx_count)
    draw_text_safe(img, 8, DISPLAY_HEIGHT - 80, tx_text, tx_color)
    draw_text_safe(img, 8, DISPLAY_HEIGHT - 56, rx_text, rx_color)


def draw_prediction_box(img, box, dx, dy):
    if not hasattr(img, "draw_rectangle"):
        return box

    x1, y1, x2, y2 = box
    box_w = x2 - x1
    box_h = y2 - y1
    pred_x = int(clamp(x1 + dx, 0, max(0, DISPLAY_WIDTH - box_w)))
    pred_y = int(clamp(y1 + dy, 0, max(0, DISPLAY_HEIGHT - box_h)))
    red = (255, 255, 0, 0)

    try:
        img.draw_rectangle(pred_x, pred_y, box_w, box_h, color=red, thickness=2)
    except BaseException:
        pass
    return pred_x, pred_y, pred_x + box_w, pred_y + box_h


def draw_center_mark(img, center_x, center_y, color):
    if not hasattr(img, "draw_line"):
        return
    x = int(center_x)
    y = int(center_y)
    try:
        img.draw_line(x - 5, y, x + 5, y, color=color, thickness=2)
        img.draw_line(x, y - 5, x, y + 5, color=color, thickness=2)
    except BaseException:
        pass


def draw_box_units(img, boxes, previous_tracks, dt_ms):
    current_tracks = []
    used_indices = []
    text_color = (255, 255, 255, 0)
    red = (255, 255, 0, 0)
    first_ball_state = None

    for box in boxes:
        center = box_center(box)
        if abs(center[1] - DISPLAY_HEIGHT / 2.0) > Y_CENTER_TOLERANCE_PX:
            continue

        previous_track = match_previous_track(center, previous_tracks, used_indices)
        if len(previous_tracks) > 0 and previous_track is None:
            continue
        previous_center = previous_track["center"] if previous_track is not None else None
        previous_x = previous_center[0] if previous_center is not None else None

        speed_units = calc_speed_units(center[0], previous_x, dt_ms)
        speed_level = int(speed_units)

        if previous_center is not None:
            dx = center[0] - previous_center[0]
            dy = center[1] - previous_center[1]
            display_box = draw_prediction_box(img, box, dx, dy)
        else:
            display_box = draw_prediction_box(img, box, 0, 0)

        # The object coordinate is the red box center, not any corner.
        object_center = box_center(display_box)
        draw_center_mark(img, object_center[0], object_center[1], red)
        position_level = calc_position_level(object_center[0])
        x_units = calc_position_units(object_center[0])
        text = "ball X:{} V:{}".format(position_level, speed_level)

        if first_ball_state is None:
            first_ball_state = {
                "x_units": x_units,
                "speed_units": speed_units,
                "position_level": position_level,
                "speed_level": speed_level,
            }

        text_x = display_box[2] + 4
        text_y = display_box[1]
        if text_x > DISPLAY_WIDTH - 160:
            text_x = display_box[0]
            text_y = display_box[3] + 4
        if text_y > DISPLAY_HEIGHT - 24:
            text_y = max(0, display_box[1] - 24)
        draw_text_safe(img, int(text_x), int(text_y), text, text_color)
        current_tracks.append({"center": center, "box": box})

    return current_tracks, first_ball_state


def open_sensor():
    last_error = None
    for sid in (2, 1, 0):
        trial = None
        try:
            print("try sensor id:", sid)
            trial = Sensor(id=sid, width=1280, height=960)
            trial.reset()
            print("use sensor id:", sid)
            return trial
        except BaseException as e:
            last_error = e
            print("sensor id", sid, "failed:", e)
            if isinstance(trial, Sensor):
                try:
                    trial.stop()
                except BaseException:
                    pass
    raise last_error


sensor = None
pl = None
yolo = None

try:
    port1_uart = init_port1_uart()

    sensor = open_sensor()
    configure_sensor(sensor)

    pl = PipeLine(
        rgb888p_size=rgb888p_size,
        display_size=display_size,
        display_mode=display_mode,
    )
    pl.create(sensor=sensor)
    display_size = pl.get_display_size()

    yolo = YOLO11(
        task_type="detect",
        mode="video",
        kmodel_path=kmodel_path,
        labels=labels,
        rgb888p_size=rgb888p_size,
        model_input_size=model_input_size,
        display_size=display_size,
        conf_thresh=confidence_threshold,
        nms_thresh=nms_threshold,
        max_boxes_num=5,
        debug_mode=0,
    )
    yolo.config_preprocess()

    frame_count = 0
    previous_tracks = []
    previous_ms = None
    active_mode = -1
    mode1 = {"phase": 0}
    mode_d = start_mode_d(0)
    mode_e = start_mode_e(0, -1, mode1, mode_d, mode_e_output_start, mode_e_output_end, "E")
    draw_capture = DrawCapture()
    uart_tx_count = 0
    uart_tx_state = 0
    uart_rx_buffer = ""
    uart_rx_count = 0
    uart_rx_state = 0
    uart_rx_text = "--"
    camera_fail_count = 0
    deadzone = {"start_ms": None, "target": None}
    away_brake = {"active": False, "target": None, "output": 0, "zero_start_ms": None}

    print("display: PipeLine lcd")
    print("detect size:", rgb888p_size)

    while True:
        os.exitpoint()
        try:
            img = pl.get_frame()
            camera_fail_count = 0
        except BaseException as e:
            camera_fail_count += 1
            print("camera frame retry {}/{}:".format(camera_fail_count, camera_retry_limit), e)
            gc.collect()
            if camera_fail_count >= camera_retry_limit:
                raise
            continue
        res = yolo.run(img)
        current_ms = now_ms()
        dt_ms = diff_ms(current_ms, previous_ms)

        pl.osd_img.clear()
        draw_capture.clear()
        yolo.draw_result(res, draw_capture)
        draw_guides(pl.osd_img)
        previous_tracks, ball_state = draw_box_units(pl.osd_img, draw_capture.boxes, previous_tracks, dt_ms)

        uart_rx_state, uart_rx_buffer, rx_line, mode_command = read_port1_rx(port1_uart, uart_rx_buffer)
        if uart_rx_state > 0:
            reset_deadzone(deadzone)
            reset_away_brake(away_brake)
            uart_rx_count += 1
            uart_rx_text = rx_line
            if mode_command is not None:
                print("PORT1 RX:{} N:{}".format(uart_rx_text, uart_rx_count))

        if mode_command == 0:
            mode1 = {"phase": 0}
            if active_mode == 0:
                active_mode = -1
                print("PORT1 CMD A: EXIT")
            else:
                active_mode = 0
                print("PORT1 CMD A: K0 CENTER")
        elif mode_command == 1:
            mode1 = {"phase": 0}
            if active_mode == 1:
                active_mode = -1
                print("PORT1 CMD C: EXIT")
            else:
                active_mode = 1
                print("PORT1 CMD C: K1 5CM")
        elif mode_command == 2:
            active_mode = 2
            mode1 = {"phase": 0}
            mode_d = start_mode_d(current_ms)
            print("PORT1 CMD D: WAIT {}ms".format(mode_d_settle_ms))
        elif mode_command == 3 or mode_command == 4:
            if active_mode == 3:
                paused_mode = mode_e.get("paused_mode", -1)
                paused_mode1 = mode_e.get("paused_mode1", mode1)
                paused_mode_d = mode_e.get("paused_mode_d", mode_d)
                pause_ms = diff_ms(current_ms, mode_e.get("start_ms", current_ms))
                if paused_mode == 2 and paused_mode_d.get("phase", 0) == 0:
                    paused_mode_d["start_ms"] = add_ms(
                        paused_mode_d.get("start_ms", current_ms),
                        pause_ms,
                    )
            else:
                paused_mode = active_mode
                paused_mode1 = mode1
                paused_mode_d = mode_d
            active_mode = 3
            if mode_command == 4:
                buffer_label = "F"
                output_start = mode_f_output_start
                output_end = mode_f_output_end
            else:
                buffer_label = "E"
                output_start = mode_e_output_start
                output_end = mode_e_output_end
            mode_e = start_mode_e(
                current_ms,
                paused_mode,
                paused_mode1,
                paused_mode_d,
                output_start,
                output_end,
                buffer_label,
            )
            print("PORT1 CMD {}: DELAY {}ms BUFFER {}ms".format(buffer_label, mode_e_delay_ms, mode_e_buffer_ms))

        if active_mode == 3 and mode_e_buffer_done(mode_e, current_ms, ball_state):
            buffer_label = mode_e.get("label", "E")
            active_mode, mode1, mode_d = restore_mode_e(mode_e, current_ms)
            print("PORT1 CMD {}: RETURN".format(buffer_label))

        if active_mode == 3:
            output_value, mode_status = mode_e_buffer_output(mode_e, current_ms)
            mode_name = mode_e.get("label", "E")
        elif active_mode == 2:
            output_value, mode_status = update_mode_d(mode_d, ball_state, current_ms)
            mode_name = "D"
        elif active_mode == 1:
            output_value, mode_status = update_mode1(mode1, ball_state)
            mode_name = "K1"
        elif active_mode == 0:
            output_value, mode_status = update_mode0(ball_state)
            mode_name = "K0"
        else:
            output_value = 0
            mode_status = "IDLE B:{:.2f}/{:.2f}".format(
                brake_factor_inner,
                brake_factor_outer,
            )
            mode_name = "WAIT"

        if "B:" not in mode_status:
            mode_status = "{} B:{:.2f}/{:.2f}".format(
                mode_status,
                brake_factor_inner,
                brake_factor_outer,
            )

        target_units = target_units_for_mode(active_mode, mode1, mode_d, mode_e)
        output_value, mode_status = update_deadzone(
            deadzone,
            active_mode,
            target_units,
            ball_state,
            output_value,
            mode_status,
            current_ms,
        )
        output_value, mode_status = update_away_brake(
            away_brake,
            active_mode,
            target_units,
            ball_state,
            output_value,
            mode_status,
            current_ms,
        )
        uart_tx_state = send_port1_value(port1_uart, output_value)
        if uart_tx_state > 0:
            uart_tx_count += 1
        if active_mode == 1 and k1_finish_t_ready(mode1, ball_state):
            t_tx_state = send_port1_value(port1_uart, "T")
            if t_tx_state > 0:
                uart_tx_count += 1
                mode1["t_sent"] = True
                mode_status = mode_status + " T"
            else:
                uart_tx_state = t_tx_state
        previous_ms = current_ms
        draw_target_center_line(
            pl.osd_img,
            target_units,
        )
        draw_uart_status(
            pl.osd_img,
            uart_tx_state,
            output_value,
            uart_tx_count,
            uart_rx_state,
            uart_rx_text,
            uart_rx_count,
        )
        draw_mode_status(pl.osd_img, mode_name, mode_status, output_value)
        draw_brake_factor(pl.osd_img)
        pl.show_image()
        del img
        del res

        frame_count += 1
        if frame_count % gc_collect_interval_frames == 0:
            gc.collect()

except KeyboardInterrupt as e:
    print("user stop:", e)
except BaseException as e:
    print("camera error:", e)
    if hasattr(sys, "print_exception"):
        sys.print_exception(e)
finally:
    try:
        if yolo is not None:
            yolo.deinit()
    except BaseException:
        pass
    if pl is not None:
        try:
            if hasattr(pl, "destroy"):
                pl.destroy()
            elif hasattr(pl, "deinit"):
                pl.deinit()
        except BaseException:
            pass
    elif isinstance(sensor, Sensor):
        try:
            sensor.stop()
        except BaseException:
            pass
    try:
        os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    except BaseException:
        pass
    gc.collect()
