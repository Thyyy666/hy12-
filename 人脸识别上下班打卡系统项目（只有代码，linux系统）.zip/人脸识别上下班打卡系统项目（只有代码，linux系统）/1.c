#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

// ??????(?????? at070tn92)
#define LCD_WIDTH  1024
#define LCD_HEIGHT 600
#define LCD_SIZE   (LCD_WIDTH * LCD_HEIGHT * 4) // 4?????

// ???????(??????,??????)
static unsigned int lcd_buffer[LCD_WIDTH * LCD_HEIGHT];

// ??? LCD:???????
static int lcd_init(void)
{
    int lcd_fd = open("/dev/fb0", O_RDWR);
    if (lcd_fd < 0)
    {
        perror("open /dev/fb0 failed");
        return -1;
    }

    // ??:????
    memset(lcd_buffer, 0x00, sizeof(lcd_buffer));
    
    // ??????
    write(lcd_fd, lcd_buffer, LCD_SIZE);
    close(lcd_fd);
    return 0;
}

// ????:?? BMP(?????????,????)
// pathname: ????
// x,y: ????
// w,h: ????
int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
    // 1. ??? LCD
    static int init_flag = 0;
    if (init_flag == 0)
    {
        if (lcd_init() < 0) return -1;
        init_flag = 1;
    }

    // 2. ?? BMP ??
    int bmp_fd = open(pathname, O_RDONLY);
    if (bmp_fd < 0)
    {
        perror("open bmp failed");
        return -1;
    }

    // 3. ?? BMP ?
    unsigned char header[54];
    read(bmp_fd, header, 54);
    
    // ?? BMP ????
    int bmp_w = *(int *)&header[18];
    int bmp_h = *(int *)&header[22];
    
    // ?? BMP ???(24?BMP?????4???)
    int line_length = bmp_w * 3;
    int padding = (4 - (line_length % 4)) % 4;

    // 4. ??????
    lseek(bmp_fd, 54, SEEK_SET);

    // 5. ????(????:BMP ?????,?????????)
    char rgb[3];
    for (int j = 0; j < h; j++)
    {
        // ?? BMP ?????(????)
        int file_row = bmp_h - 1 - j;
        int offset = 54 + file_row * (line_length + padding);
        
        // ?????
        lseek(bmp_fd, offset, SEEK_SET);

        // ??????????
        for (int i = 0; i < w; i++)
        {
            read(bmp_fd, rgb, 3); // ?? BGR

            // ??????
            int px = x + i;
            int py = y + j;

            // ????:??????
            if (px >= LCD_WIDTH || py >= LCD_HEIGHT) continue;

            // ?? ARGB ?? (Alpha=0xFF ???)
            unsigned int color = (0xFF << 24) | (rgb[2] << 16) | (rgb[1] << 8) | rgb[0];

            // ???????(??????????)
            lcd_buffer[py * LCD_WIDTH + px] = color;
        }
        
        // ????????
        lseek(bmp_fd, padding, SEEK_CUR);
    }

    // 6. ?? BMP
    close(bmp_fd);
    return 0;
}

// ????:?????????????
void lcd_refresh(void)
{
    int lcd_fd = open("/dev/fb0", O_RDWR);
    if (lcd_fd >= 0)
    {
        write(lcd_fd, lcd_buffer, LCD_SIZE);
        close(lcd_fd);
    }
}

int main(void)
{
    // ?? ???????
    lcd_draw_bmp("1234.bmp", 0,   0,   200, 100); // ??
    lcd_draw_bmp("123.bmp",  212, 400, 600, 200); // ??

    // ?? ??????,?????????
    lcd_refresh();

    // ????,?????????????
    while (1)
    {
        sleep(100); // ????
    }
    return 0;
}