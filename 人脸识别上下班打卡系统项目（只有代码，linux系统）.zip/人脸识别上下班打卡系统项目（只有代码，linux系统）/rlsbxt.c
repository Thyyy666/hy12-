#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include "jpeglib.h"
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include "DRMwrap.h"
#include <stdlib.h>
#include <dirent.h>
#include <linux/input.h>
#include <stdbool.h>
#include <pthread.h>
#include "camera_capture_yuyv.h"
#include "image.h"

// ==============================
// 全局设备句柄
// ==============================
int drm_fd = -1, ts_fd = -1;
struct drmHandle drm;
uint32_t *lcd_ptr = NULL;
void dev_uninit(void);

// ==============================
// 摄像头相关全局变量&互斥锁（防止多线程画面冲突）
// ==============================
int camera_fd = -1;
int snap_flag = 0;          // 抓拍触发标志
int camera_running = 0;      // 摄像头运行状态标志
struct buffer jpeg_buf;      // 摄像头实时帧缓冲区
struct buffer snap_buf;      // 抓拍画面缓冲区
pthread_t camera_tid;
pthread_mutex_t cam_mutex = PTHREAD_MUTEX_INITIALIZER; // 缓冲区互斥锁
static int clock_in_num = 0;  // 上班打卡抓拍序号
static int clock_out_num = 0; // 下班打卡抓拍序号

// ==============================
// 页面状态定义（移除了单独的摄像头页面，集成到打卡页内）
// ==============================
typedef enum {
    PAGE_HOME,          // 第1页：人脸识别首页
    PAGE_SELECT,        // 第2页：登录选择页
    PAGE_USER_LOGIN,    // 第3页：用户登录页
    PAGE_ADMIN,         // 第4页：管理员操作中心
    PAGE_CLOCK,         // 第5页：打卡页面（核心修改页，集成摄像头）
    PAGE_KEYBOARD       // 第6页：数字键盘输入页
} PageState;

PageState current_page = PAGE_HOME;

// ==============================
// 数字键盘输入全局变量
// ==============================
char input_buf[20] = {0};       // 存储当前输入的数字/符号
int input_len = 0;               // 当前输入长度
typedef enum {INPUT_NONE, INPUT_USER_ID, INPUT_USER_PWD, INPUT_ADMIN_ID, INPUT_ADMIN_PWD} InputType;
InputType current_input = INPUT_NONE; // 当前激活的输入框类型
char user_id[20] = {0};
char user_pwd[20] = {0};
char admin_id[20] = {0};
char admin_pwd[20] = {0};

// ==================================================
// 🔴 配置宏定义区（你要改的所有参数全在这里，直接改数值即可）
// ==================================================
// ------------------------------
// 1. 账号密码设置（原有保留）
// ------------------------------
#define DEFAULT_USER_ID      "123456"   // 用户工号
#define DEFAULT_USER_PWD     "123456"   // 用户密码
#define DEFAULT_ADMIN_ID     "123456"   // 管理员工号
#define DEFAULT_ADMIN_PWD    "123456"  // 管理员密码

// ------------------------------
// 2. 打卡页专属配置（核心修改项，你直接调数值）
// ------------------------------
// 🔹 左上角摄像头实时预览区域（位置+大小，直接改）
#define CAM_PREVIEW_X        20    // 预览画面X坐标（左上角）
#define CAM_PREVIEW_Y        20    // 预览画面Y坐标（左上角）
#define CAM_PREVIEW_W        640   // 预览画面宽度
#define CAM_PREVIEW_H        480   // 预览画面高度
#define CAM_PREVIEW_ZOOM     1     // 预览画面缩放比例（1=原始大小，2=缩小一半）

// 🔹 右上角抓拍小画面显示区域（位置+大小，直接改）
#define SNAP_SHOW_X          680   // 抓拍画面X坐标（右上角）
#define SNAP_SHOW_Y          20    // 抓拍画面Y坐标（右上角）
#define SNAP_SHOW_W          300   // 抓拍画面宽度
#define SNAP_SHOW_H          200   // 抓拍画面高度
#define SNAP_SHOW_ZOOM       2     // 抓拍画面缩放比例（数值越大画面越小）

// 🔹 右侧按钮布局（屏幕最右边，垂直并列，直接改坐标）
// 通用按钮宽度/高度（统一设置，保持整齐）
#define BTN_CLOCK_W          220
#define BTN_CLOCK_H          90
// 按钮X坐标（统一靠右，1024-220-20=784，在屏幕最右侧留20px边距）
#define BTN_CLOCK_X          784
// 按钮Y坐标（垂直并列，从上到下：返回→上班打卡→下班打卡）
#define BTN_BACK_CLOCK_Y     100   // 返回按钮Y坐标
#define BTN_IN_CLOCK_Y       250   // 上班打卡按钮Y坐标
#define BTN_OUT_CLOCK_Y      400   // 下班打卡按钮Y坐标

// ------------------------------
// 3. 所有页面背景图（原有保留，素材不变）
// ------------------------------
#define PAGE1_BG_IMG      "xtjm.bmp"
#define PAGE1_BG_X        0
#define PAGE1_BG_Y        0
#define PAGE1_BG_W        1024
#define PAGE1_BG_H        600

#define PAGE2_BG_IMG      "dljm.bmp"
#define PAGE2_BG_X        0
#define PAGE2_BG_Y        0
#define PAGE2_BG_W        1024
#define PAGE2_BG_H        600

#define PAGE3_BG_IMG      "yhdl.bmp"
#define PAGE3_BG_X        0
#define PAGE3_BG_Y        0
#define PAGE3_BG_W        1024
#define PAGE3_BG_H        600

#define PAGE4_BG_IMG      "glyjm.bmp"
#define PAGE4_BG_X        0
#define PAGE4_BG_Y        0
#define PAGE4_BG_W        1024
#define PAGE4_BG_H        600

#define PAGE5_BG_IMG      "xtym.bmp"
#define PAGE5_BG_X        0
#define PAGE5_BG_Y        0
#define PAGE5_BG_W        1024
#define PAGE5_BG_H        600

#define PAGE6_BG_IMG      "srjm.bmp"
#define PAGE6_BG_X        0
#define PAGE6_BG_Y        0
#define PAGE6_BG_W        1024
#define PAGE6_BG_H        600

// ------------------------------
// 4. 所有按钮素材（原有保留，素材不变）
// ------------------------------
// 首页按钮
#define BTN_ENTER_IMG     "jrxten.bmp"
#define BTN_ENTER_X       312
#define BTN_ENTER_Y       450
#define BTN_ENTER_W       400
#define BTN_ENTER_H       100

// 登录选择页按钮
#define BTN_BACK1_IMG     "fhen.bmp"
#define BTN_BACK1_X       0
#define BTN_BACK1_Y       0
#define BTN_BACK1_W       280
#define BTN_BACK1_H       80

#define BTN_USER_IMG      "yhdlen.bmp"
#define BTN_USER_X        212
#define BTN_USER_Y        150
#define BTN_USER_W        600
#define BTN_USER_H        150

#define BTN_ADMIN_IMG     "glydlen.bmp"
#define BTN_ADMIN_X       212
#define BTN_ADMIN_Y       350
#define BTN_ADMIN_W       600
#define BTN_ADMIN_H       150

// 用户登录页按钮
#define BTN_BACK2_IMG     "fhen.bmp"
#define BTN_BACK2_X       0
#define BTN_BACK2_Y       0
#define BTN_BACK2_W       280
#define BTN_BACK2_H       80

#define BTN_SUBMIT_IMG    "dlen.bmp"
#define BTN_SUBMIT_X      362
#define BTN_SUBMIT_Y      420
#define BTN_SUBMIT_W      300
#define BTN_SUBMIT_H      80

// 管理员页按钮
#define BTN_BACK3_IMG     "fhen.bmp"
#define BTN_BACK3_X       0
#define BTN_BACK3_Y       0
#define BTN_BACK3_W       280
#define BTN_BACK3_H       80

#define BTN_EXIT_IMG      "tcxten.bmp"
#define BTN_EXIT_X        824
#define BTN_EXIT_Y        0
#define BTN_EXIT_W        200
#define BTN_EXIT_H        80

#define BTN_REG_IMG       "zcen.bmp"
#define BTN_REG_X         200
#define BTN_REG_Y         450
#define BTN_REG_W         200
#define BTN_REG_H         80

#define BTN_QUERY_IMG     "cxlben.bmp"
#define BTN_QUERY_X       624
#define BTN_QUERY_Y       450
#define BTN_QUERY_W       200
#define BTN_QUERY_H       80

// 打卡页按钮（素材不变，坐标已移到最右侧）
#define BTN_BACK4_IMG     "fhen.bmp"
#define BTN_IN_IMG        "sben.bmp"
#define BTN_OUT_IMG       "xben.bmp"

// ------------------------------
// 5. 输入框触摸区域（原有保留）
// ------------------------------
#define USER_ID_X         320
#define USER_ID_Y         135
#define USER_ID_W         600
#define USER_ID_H         150

#define USER_PWD_X        320
#define USER_PWD_Y        320
#define USER_PWD_W        600
#define USER_PWD_H        100

#define ADMIN_ID_X        250
#define ADMIN_ID_Y        240
#define ADMIN_ID_W        600
#define ADMIN_ID_H        100

#define ADMIN_PWD_X       250
#define ADMIN_PWD_Y       360
#define ADMIN_PWD_W        600
#define ADMIN_PWD_H        100

// ------------------------------
// 6. 数字键盘触摸区域（原有保留）
// ------------------------------
#define INPUT_DISPLAY_X   50
#define INPUT_DISPLAY_Y   30
#define INPUT_DISPLAY_W   924
#define INPUT_DISPLAY_H   70

// 数字键
#define BTN_1_X           40
#define BTN_1_Y           120
#define BTN_1_W           280
#define BTN_1_H           70
#define BTN_2_X           362
#define BTN_2_Y           120
#define BTN_2_W           280
#define BTN_2_H           70
#define BTN_3_X           684
#define BTN_3_Y           120
#define BTN_3_W           280
#define BTN_3_H           70
#define BTN_4_X           40
#define BTN_4_Y           215
#define BTN_4_W           280
#define BTN_4_H           70
#define BTN_5_X           362
#define BTN_5_Y           215
#define BTN_5_W           280
#define BTN_5_H           70
#define BTN_6_X           684
#define BTN_6_Y           215
#define BTN_6_W           280
#define BTN_6_H           70
#define BTN_7_X           40
#define BTN_7_Y           310
#define BTN_7_W           280
#define BTN_7_H           70
#define BTN_8_X           362
#define BTN_8_Y           310
#define BTN_8_W           280
#define BTN_8_H           70
#define BTN_9_X           684
#define BTN_9_Y           310
#define BTN_9_W           280
#define BTN_9_H           70
#define BTN_0_X           362
#define BTN_0_Y           405
#define BTN_0_W           280
#define BTN_0_H           70

// *和#按键
#define BTN_STAR_X        40
#define BTN_STAR_Y        405
#define BTN_STAR_W        280
#define BTN_STAR_H        70
#define BTN_SHARP_X       684
#define BTN_SHARP_Y       405
#define BTN_SHARP_W       280
#define BTN_SHARP_H       70

// OK键
#define BTN_OK_X          312
#define BTN_OK_Y          500
#define BTN_OK_W          400
#define BTN_OK_H          80

// ------------------------------
// 7. 错误提示弹框（原有保留）
// ------------------------------
#define ERROR_IMG         "cw.bmp"
#define ERROR_X           312
#define ERROR_Y           200
#define ERROR_W           400
#define ERROR_H           200

// ==================================================
// 触摸点结构
// ==================================================
typedef struct
{
	int x, y, pressure;
	bool valid;
} TouchPoint;

// ==================================================
// JPEG解码与显示函数（优化：支持指定位置绘制，原有功能完整保留）
// ==================================================
struct my_error_mgr
{
	struct jpeg_error_mgr pub;
	jmp_buf setjmp_buffer;
};
typedef struct my_error_mgr *my_error_ptr;

METHODDEF(void) my_error_exit(j_common_ptr cinfo)
{
	my_error_ptr myerr = (my_error_ptr)cinfo->err;
	(*cinfo->err->output_message)(cinfo);
	longjmp(myerr->setjmp_buffer, 1);
}

int jpg_to_rgb(unsigned char *jpg_buffer, size_t jpg_size, struct image_info *minfo, int zoom_flag)
{
	struct jpeg_decompress_struct cinfo;
	struct my_error_mgr jerr;
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = my_error_exit;
	if (setjmp(jerr.setjmp_buffer))
	{
		jpeg_destroy_decompress(&cinfo);
		return -1;
	}
	jpeg_create_decompress(&cinfo);
	jpeg_mem_src(&cinfo, jpg_buffer, jpg_size);
	if (jpeg_read_header(&cinfo, TRUE) != 1)
	{
		fprintf(stderr, "JPEG header read failed\n");
		return -1;
	}
	cinfo.scale_num = 1;
	cinfo.scale_denom = zoom_flag;
	jpeg_start_decompress(&cinfo);
	minfo->width = cinfo.output_width;
	minfo->height = cinfo.output_height;
	int row_stride = cinfo.output_width * cinfo.output_components;
	minfo->rgb = calloc(1, cinfo.output_height * row_stride);
	if (!minfo->rgb)
	{
		fprintf(stderr, "Memory allocation failed\n");
		jpeg_destroy_decompress(&cinfo);
		return -1;
	}
	while (cinfo.output_scanline < cinfo.output_height)
	{
		unsigned char *buffer_array[1];
		buffer_array[0] = (unsigned char *)(minfo->rgb + (cinfo.output_scanline) * row_stride);
		jpeg_read_scanlines(&cinfo, buffer_array, 1);
	}
	jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);
	return 0;
}

void load_jpeg_from_file(const char *jpgfile, struct image_info *minfo, int zoom_flag)
{
	struct stat file_info;
	if (stat(jpgfile, &file_info) == -1) return;
	int fd = open(jpgfile, O_RDONLY);
	if (fd == -1) return;
	unsigned char *jpg_buffer = (unsigned char *)calloc(1, file_info.st_size);
	if (!jpg_buffer) { close(fd); return; }
	ssize_t nread = read(fd, jpg_buffer, file_info.st_size);
	close(fd);
	if (nread <= 0) { free(jpg_buffer); return; }
	jpg_to_rgb(jpg_buffer, nread, minfo, zoom_flag);
	free(jpg_buffer);
}

// 优化版JPEG绘制函数：支持指定X/Y坐标绘制，不再强制满屏
int lcd_draw_jpeg(int x, int y, const char *pathname, unsigned char *jpeg_buffer, long unsigned int jpeg_size, struct drmHandle *drm, int zoom_flag)
{
	struct image_info *minfo = (struct image_info *)calloc(1, sizeof(struct image_info));
	if (!minfo) return -1;

	if (jpeg_buffer && jpeg_size > 0)
	{
		if (jpg_to_rgb(jpeg_buffer, jpeg_size, minfo, zoom_flag) != 0)
		{
			free(minfo);
			return -1;
		}
	}
	else if (pathname)
	{
		load_jpeg_from_file(pathname, minfo, zoom_flag);
		if (!minfo->rgb)
		{
			free(minfo);
			return -1;
		}
	}
	else
	{
		free(minfo);
		return -1;
	}

    // 按指定X/Y坐标绘制，超出屏幕部分自动裁剪
	int i, j;
	for (i = 0; i < minfo->height && (y + i) < drm->height; i++)
	{
		for (j = 0; j < minfo->width && (x + j) < drm->width; j++)
		{
			uint32_t lcd_offset = 4 * (x + j) + drm->width * 4 * (y + i);
			uint32_t rgb_offset = 3 * j + minfo->width * 3 * i;
			memcpy(drm->vaddr + lcd_offset + 0, minfo->rgb + rgb_offset + 2, 1);
			memcpy(drm->vaddr + lcd_offset + 1, minfo->rgb + rgb_offset + 1, 1);
			memcpy(drm->vaddr + lcd_offset + 2, minfo->rgb + rgb_offset + 0, 1);
		}
	}
	free(minfo->rgb);
	free(minfo);
    DRMshowUp(drm_fd, drm);
	return 0;
}

// 原有BMP显示函数（完整保留）
int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
	int bmp_fd = open(pathname, O_RDONLY);
	if (bmp_fd < 0) {
		fprintf(stderr, "警告：找不到图片 %s\n", pathname);
		return -1;
	}
	char header[54] = {0};
	char rgb_buf[w * h * 3];
	read(bmp_fd, header, 54);
	read(bmp_fd, rgb_buf, w * h * 3);

	int i, j, r, g, b, color;
	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			b = rgb_buf[(w * j + i) * 3 + 0];
			g = rgb_buf[(w * j + i) * 3 + 1];
			r = rgb_buf[(w * j + i) * 3 + 2];
			color = b | g << 8 | r << 16 | 0 << 24;
			lcd_ptr[1024 * (h - 1 - j + y) + i + x] = color;
		}
	}
	close(bmp_fd);
    DRMshowUp(drm_fd, &drm);
	return 0;
}

// ==================================================
// 数字绘制函数（完整保留，支持*#）
// ==================================================
const unsigned char digit_font[12][16] = {
    {0x00,0x00,0x3C,0x66,0x66,0x6E,0x76,0x66,0x66,0x66,0x66,0x3C,0x00,0x00,0x00,0x00}, // 0
    {0x00,0x00,0x18,0x38,0x78,0x18,0x18,0x18,0x18,0x18,0x18,0x7E,0x00,0x00,0x00,0x00}, // 1
    {0x00,0x00,0x3C,0x66,0x66,0x06,0x0C,0x18,0x30,0x60,0x66,0x7E,0x00,0x00,0x00,0x00}, // 2
    {0x00,0x00,0x3C,0x66,0x66,0x06,0x1C,0x06,0x06,0x66,0x66,0x3C,0x00,0x00,0x00,0x00}, // 3
    {0x00,0x00,0x0C,0x1C,0x3C,0x6C,0xCC,0xFE,0x0C,0x0C,0x0C,0x1E,0x00,0x00,0x00,0x00}, // 4
    {0x00,0x00,0x7E,0x60,0x60,0x7C,0x66,0x06,0x06,0x66,0x66,0x3C,0x00,0x00,0x00,0x00}, // 5
    {0x00,0x00,0x1C,0x30,0x60,0x60,0x7C,0x66,0x66,0x66,0x66,0x3C,0x00,0x00,0x00,0x00}, // 6
    {0x00,0x00,0x7E,0x66,0x06,0x0C,0x18,0x30,0x30,0x30,0x30,0x30,0x00,0x00,0x00,0x00}, // 7
    {0x00,0x00,0x3C,0x66,0x66,0x66,0x3C,0x66,0x66,0x66,0x66,0x3C,0x00,0x00,0x00,0x00}, // 8
    {0x00,0x00,0x3C,0x66,0x66,0x66,0x66,0x3E,0x06,0x06,0x0C,0x38,0x00,0x00,0x00,0x00}, // 9
    {0x00,0x00,0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, // 10: *
    {0x00,0x00,0x18,0x18,0x7E,0x18,0x18,0x7E,0x18,0x18,0x00,0x00,0x00,0x00,0x00,0x00}  // 11: #
};

void lcd_draw_digit(int x, int y, char c, uint32_t color)
{
    int num = -1;
    if (c >= '0' && c <= '9') {
        num = c - '0';
    } else if (c == '*') {
        num = 10;
    } else if (c == '#') {
        num = 11;
    } else {
        return;
    }

    int i, j;
    for (i = 0; i < 16; i++)
    {
        unsigned char line = digit_font[num][i];
        for (j = 0; j < 8; j++)
        {
            if (line & (0x80 >> j))
            {
                for (int m = 0; m < 3; m++) {
                    for (int n = 0; n < 3; n++) {
                        lcd_ptr[1024 * (y + i * 3 + m) + (x + j * 3 + n)] = color;
                    }
                }
            }
        }
    }
}

void lcd_draw_number(int x, int y, const char *num, uint32_t color)
{
    int i = 0;
    while (num[i] != '\0' && i < 20)
    {
        lcd_draw_digit(x + i * 30, y, num[i], color);
        i++;
    }
}

// ==================================================
// 🔴 打卡页专属：摄像头实时采集线程（仅在打卡页运行，渲染到左上角）
// ==================================================
void *clock_camera_thread(void *arg)
{
	pthread_detach(pthread_self());
	camera_running = 1; // 标记摄像头正在运行

	while (camera_running == 1)
	{
        // 仅在打卡页面时渲染画面
        if (current_page == PAGE_CLOCK)
        {
            // 加锁获取摄像头帧数据，防止和抓拍冲突
            pthread_mutex_lock(&cam_mutex);
            camera_capture_get_frame(&jpeg_buf);
            yuyv2jpeg(jpeg_buf.start, jpeg_buf.length, 99);
            // 实时渲染到左上角预览区域
            lcd_draw_jpeg(CAM_PREVIEW_X, CAM_PREVIEW_Y, NULL, jpeg_buf.start, jpeg_buf.length, &drm, CAM_PREVIEW_ZOOM);
            pthread_mutex_unlock(&cam_mutex);
        }
        usleep(30000); // 30ms一帧，流畅不占CPU
	}

    // 线程退出前释放摄像头资源
    camera_capture_stop_capturing();
    camera_capture_uninit(&jpeg_buf);
    camera_capture_close();
    pthread_exit(NULL);
}

// ==================================================
// 🔴 打卡页专属：抓拍&显示函数（上班/下班打卡通用）
// ==================================================
void clock_snap_and_show(int is_clock_in)
{
    char pic_name[30] = {0};
    // 生成文件名，区分上班/下班打卡
    if (is_clock_in)
    {
        sprintf(pic_name, "clock_in_%d.jpg", clock_in_num++);
        printf("✅ 上班打卡抓拍成功，保存为：%s\n", pic_name);
    }
    else
    {
        sprintf(pic_name, "clock_out_%d.jpg", clock_out_num++);
        printf("✅ 下班打卡抓拍成功，保存为：%s\n", pic_name);
    }

    // 加锁拷贝当前帧数据，防止和预览线程冲突
    pthread_mutex_lock(&cam_mutex);
    // 分配抓拍缓冲区
    snap_buf.length = jpeg_buf.length;
    snap_buf.start = realloc(snap_buf.start, snap_buf.length);
    memcpy(snap_buf.start, jpeg_buf.start, snap_buf.length);
    pthread_mutex_unlock(&cam_mutex);

    // 保存抓拍图片到本地
    int pic_fd = open(pic_name, O_RDWR | O_CREAT, 0777);
    if (pic_fd != -1)
    {
        write(pic_fd, snap_buf.start, snap_buf.length);
        close(pic_fd);
    }

    // 渲染抓拍画面到右上角小窗口
    lcd_draw_jpeg(SNAP_SHOW_X, SNAP_SHOW_Y, NULL, snap_buf.start, snap_buf.length, &drm, SNAP_SHOW_ZOOM);
}

// ==================================================
// 页面显示函数（核心修改：打卡页面布局）
// ==================================================
void show_current_page(void)
{
    memset(lcd_ptr, 0, 1024 * 600 * 4);
    switch(current_page)
    {
        case PAGE_HOME:
            lcd_draw_bmp(PAGE1_BG_IMG, PAGE1_BG_X, PAGE1_BG_Y, PAGE1_BG_W, PAGE1_BG_H);
            lcd_draw_bmp(BTN_ENTER_IMG, BTN_ENTER_X, BTN_ENTER_Y, BTN_ENTER_W, BTN_ENTER_H);
            lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
            break;
        case PAGE_SELECT:
            lcd_draw_bmp(PAGE2_BG_IMG, PAGE2_BG_X, PAGE2_BG_Y, PAGE2_BG_W, PAGE2_BG_H);
            lcd_draw_bmp(BTN_BACK1_IMG, BTN_BACK1_X, BTN_BACK1_Y, BTN_BACK1_W, BTN_BACK1_H);
            lcd_draw_bmp(BTN_USER_IMG, BTN_USER_X, BTN_USER_Y, BTN_USER_W, BTN_USER_H);
            lcd_draw_bmp(BTN_ADMIN_IMG, BTN_ADMIN_X, BTN_ADMIN_Y, BTN_ADMIN_W, BTN_ADMIN_H);
            lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
            break;
        case PAGE_USER_LOGIN:
            lcd_draw_bmp(PAGE3_BG_IMG, PAGE3_BG_X, PAGE3_BG_Y, PAGE3_BG_W, PAGE3_BG_H);
            lcd_draw_bmp(BTN_BACK2_IMG, BTN_BACK2_X, BTN_BACK2_Y, BTN_BACK2_W, BTN_BACK2_H);
            lcd_draw_bmp(BTN_SUBMIT_IMG, BTN_SUBMIT_X, BTN_SUBMIT_Y, BTN_SUBMIT_W, BTN_SUBMIT_H);
            lcd_draw_number(USER_ID_X + 5, USER_ID_Y + 15, user_id, 0x000000);
            lcd_draw_number(USER_PWD_X + 5, USER_PWD_Y + 15, user_pwd, 0x000000);
            lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
            break;
        case PAGE_ADMIN:
            lcd_draw_bmp(PAGE4_BG_IMG, PAGE4_BG_X, PAGE4_BG_Y, PAGE4_BG_W, PAGE4_BG_H);
            lcd_draw_bmp(BTN_BACK3_IMG, BTN_BACK3_X, BTN_BACK3_Y, BTN_BACK3_W, BTN_BACK3_H);
            lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
            lcd_draw_bmp(BTN_REG_IMG, BTN_REG_X, BTN_REG_Y, BTN_REG_W, BTN_REG_H);
            lcd_draw_bmp(BTN_QUERY_IMG, BTN_QUERY_X, BTN_QUERY_Y, BTN_QUERY_W, BTN_QUERY_H);
            lcd_draw_number(ADMIN_ID_X + 5, ADMIN_ID_Y + 10, admin_id, 0x000000);
            lcd_draw_number(ADMIN_PWD_X + 5, ADMIN_PWD_Y + 10, admin_pwd, 0x000000);
            break;
        // 🔴 核心修改：打卡页面布局
        case PAGE_CLOCK:
            // 1. 先绘制背景
            lcd_draw_bmp(PAGE5_BG_IMG, PAGE5_BG_X, PAGE5_BG_Y, PAGE5_BG_W, PAGE5_BG_H);
            // 2. 绘制最右侧的三个按钮（垂直并列）
            lcd_draw_bmp(BTN_BACK4_IMG, BTN_CLOCK_X, BTN_BACK_CLOCK_Y, BTN_CLOCK_W, BTN_CLOCK_H);
            lcd_draw_bmp(BTN_IN_IMG, BTN_CLOCK_X, BTN_IN_CLOCK_Y, BTN_CLOCK_W, BTN_CLOCK_H);
            lcd_draw_bmp(BTN_OUT_IMG, BTN_CLOCK_X, BTN_OUT_CLOCK_Y, BTN_CLOCK_W, BTN_CLOCK_H);
            // ❌ 已移除打卡页的退出系统按钮，防止误触
            break;
        case PAGE_KEYBOARD:
            lcd_draw_bmp(PAGE6_BG_IMG, PAGE6_BG_X, PAGE6_BG_Y, PAGE6_BG_W, PAGE6_BG_H);
            lcd_draw_number(INPUT_DISPLAY_X + 10, INPUT_DISPLAY_Y + 10, input_buf, 0x000000);
            break;
        default:
            break;
    }
    DRMshowUp(drm_fd, &drm);
}

// ==================================================
// 触摸事件处理函数（核心修改：打卡页按钮逻辑）
// ==================================================
TouchPoint get_touch_data(int fd)
{
	struct input_event ev;
	static TouchPoint point = {0};
	point.valid = false;
	while (read(fd, &ev, sizeof(ev)) == sizeof(ev))
	{
		switch (ev.type)
		{
		case EV_ABS:
			if (ev.code == ABS_X) point.x = ev.value;
			if (ev.code == ABS_Y) point.y = ev.value;
			if (ev.code == ABS_PRESSURE) point.pressure = ev.value;
			break;
		case EV_KEY:
			if (ev.code == BTN_TOUCH && ev.value == 0)
			{
				point.valid = true;
				return point;
			}
			break;
		}
	}
	return (TouchPoint){0};
}

void check_touch_buttons(TouchPoint p)
{
    // 通用退出按钮（仅非打卡页面生效，打卡页已移除）
    if (current_page != PAGE_CLOCK && current_page != PAGE_KEYBOARD &&
        p.x >= BTN_EXIT_X && p.x <= BTN_EXIT_X + BTN_EXIT_W &&
        p.y >= BTN_EXIT_Y && p.y <= BTN_EXIT_Y + BTN_EXIT_H)
    {
        printf("👉 退出系统\n");
        dev_uninit();
        exit(0);
    }

    switch(current_page)
    {
        case PAGE_HOME:
            if (p.x >= BTN_ENTER_X && p.x <= BTN_ENTER_X + BTN_ENTER_W &&
                p.y >= BTN_ENTER_Y && p.y <= BTN_ENTER_Y + BTN_ENTER_H)
            {
                printf("👉 进入系统 → 登录选择页\n");
                current_page = PAGE_SELECT;
                show_current_page();
            }
            break;
        case PAGE_SELECT:
            if (p.x >= BTN_BACK1_X && p.x <= BTN_BACK1_X + BTN_BACK1_W &&
                p.y >= BTN_BACK1_Y && p.y <= BTN_BACK1_Y + BTN_BACK1_H)
            {
                printf("👉 返回 → 首页\n");
                current_page = PAGE_HOME;
                show_current_page();
            }
            else if (p.x >= BTN_USER_X && p.x <= BTN_USER_X + BTN_USER_W &&
                     p.y >= BTN_USER_Y && p.y <= BTN_USER_Y + BTN_USER_H)
            {
                printf("👉 用户登录 → 用户登录页\n");
                current_page = PAGE_USER_LOGIN;
                show_current_page();
            }
            else if (p.x >= BTN_ADMIN_X && p.x <= BTN_ADMIN_X + BTN_ADMIN_W &&
                     p.y >= BTN_ADMIN_Y && p.y <= BTN_ADMIN_Y + BTN_ADMIN_H)
            {
                printf("👉 管理员登录 → 管理员中心\n");
                current_page = PAGE_ADMIN;
                show_current_page();
            }
            break;
        case PAGE_USER_LOGIN:
            if (p.x >= BTN_BACK2_X && p.x <= BTN_BACK2_X + BTN_BACK2_W &&
                p.y >= BTN_BACK2_Y && p.y <= BTN_BACK2_Y + BTN_BACK2_H)
            {
                printf("👉 返回 → 登录选择页\n");
                current_page = PAGE_SELECT;
                show_current_page();
            }
            else if (p.x >= USER_ID_X && p.x <= USER_ID_X + USER_ID_W &&
                     p.y >= USER_ID_Y && p.y <= USER_ID_Y + USER_ID_H)
            {
                printf("👉 点击工号输入框 → 数字键盘\n");
                current_input = INPUT_USER_ID;
                memset(input_buf, 0, sizeof(input_buf));
                input_len = 0;
                current_page = PAGE_KEYBOARD;
                show_current_page();
            }
            else if (p.x >= USER_PWD_X && p.x <= USER_PWD_X + USER_PWD_W &&
                     p.y >= USER_PWD_Y && p.y <= USER_PWD_Y + USER_PWD_H)
            {
                printf("👉 点击密码输入框 → 数字键盘\n");
                current_input = INPUT_USER_PWD;
                memset(input_buf, 0, sizeof(input_buf));
                input_len = 0;
                current_page = PAGE_KEYBOARD;
                show_current_page();
            }
            else if (p.x >= BTN_SUBMIT_X && p.x <= BTN_SUBMIT_X + BTN_SUBMIT_W &&
                     p.y >= BTN_SUBMIT_Y && p.y <= BTN_SUBMIT_Y + BTN_SUBMIT_H)
            {
                if (strcmp(user_id, DEFAULT_USER_ID) == 0 && strcmp(user_pwd, DEFAULT_USER_PWD) == 0)
                {
                    printf("✅ 用户登录成功 → 打卡页\n");
                    current_page = PAGE_CLOCK;
                    show_current_page();
                    // 🔴 进入打卡页，自动打开摄像头，启动采集线程
                    if (0 != camera_capture_open(DEV_CAMERA))
                    {
                        printf("❌ 摄像头设备打开失败\n");
                    }
                    else
                    {
                        camera_capture_init(&jpeg_buf);
                        camera_capture_start_capturing();
                        pthread_create(&camera_tid, NULL, clock_camera_thread, NULL);
                        printf("✅ 打卡页摄像头已自动开启\n");
                    }
                }
                else
                {
                    printf("❌ 账号或密码错误\n");
                    lcd_draw_bmp(ERROR_IMG, ERROR_X, ERROR_Y, ERROR_W, ERROR_H);
                    DRMshowUp(drm_fd, &drm);
                    sleep(2);
                    show_current_page();
                }
            }
            break;
        case PAGE_ADMIN:
            if (p.x >= BTN_BACK3_X && p.x <= BTN_BACK3_X + BTN_BACK3_W &&
                p.y >= BTN_BACK3_Y && p.y <= BTN_BACK3_Y + BTN_BACK3_H)
            {
                printf("👉 返回 → 登录选择页\n");
                current_page = PAGE_SELECT;
                show_current_page();
            }
            else if (p.x >= ADMIN_ID_X && p.x <= ADMIN_ID_X + ADMIN_ID_W &&
                     p.y >= ADMIN_ID_Y && p.y <= ADMIN_ID_Y + ADMIN_ID_H)
            {
                printf("👉 点击管理员工号输入框 → 数字键盘\n");
                current_input = INPUT_ADMIN_ID;
                memset(input_buf, 0, sizeof(input_buf));
                input_len = 0;
                current_page = PAGE_KEYBOARD;
                show_current_page();
            }
            else if (p.x >= ADMIN_PWD_X && p.x <= ADMIN_PWD_X + ADMIN_PWD_W &&
                     p.y >= ADMIN_PWD_Y && p.y <= ADMIN_PWD_Y + ADMIN_PWD_H)
            {
                printf("👉 点击管理员密码输入框 → 数字键盘\n");
                current_input = INPUT_ADMIN_PWD;
                memset(input_buf, 0, sizeof(input_buf));
                input_len = 0;
                current_page = PAGE_KEYBOARD;
                show_current_page();
            }
            break;
        // 🔴 核心修改：打卡页按钮触摸逻辑
        case PAGE_CLOCK:
            // 返回按钮：停止摄像头，返回用户登录页
            if (p.x >= BTN_CLOCK_X && p.x <= BTN_CLOCK_X + BTN_CLOCK_W &&
                p.y >= BTN_BACK_CLOCK_Y && p.y <= BTN_BACK_CLOCK_Y + BTN_CLOCK_H)
            {
                printf("👉 返回 → 用户登录页\n");
                // 停止摄像头线程，释放资源
                camera_running = 0;
                pthread_join(camera_tid, NULL);
                // 释放抓拍缓冲区
                if (snap_buf.start)
                {
                    free(snap_buf.start);
                    snap_buf.start = NULL;
                    snap_buf.length = 0;
                }
                current_page = PAGE_USER_LOGIN;
                show_current_page();
            }
            // 上班打卡按钮：立即抓拍，右上角显示
            else if (p.x >= BTN_CLOCK_X && p.x <= BTN_CLOCK_X + BTN_CLOCK_W &&
                     p.y >= BTN_IN_CLOCK_Y && p.y <= BTN_IN_CLOCK_Y + BTN_CLOCK_H)
            {
                clock_snap_and_show(1); // 1=上班打卡
            }
            // 下班打卡按钮：立即抓拍，右上角显示
            else if (p.x >= BTN_CLOCK_X && p.x <= BTN_CLOCK_X + BTN_CLOCK_W &&
                     p.y >= BTN_OUT_CLOCK_Y && p.y <= BTN_OUT_CLOCK_Y + BTN_CLOCK_H)
            {
                clock_snap_and_show(0); // 0=下班打卡
            }
            break;
        case PAGE_KEYBOARD:
            // 数字键0-9
            if (p.x >= BTN_1_X && p.x <= BTN_1_X + BTN_1_W && p.y >= BTN_1_Y && p.y <= BTN_1_Y + BTN_1_H && input_len < 19) {
                input_buf[input_len++] = '1';
                show_current_page();
            } else if (p.x >= BTN_2_X && p.x <= BTN_2_X + BTN_2_W && p.y >= BTN_2_Y && p.y <= BTN_2_Y + BTN_2_H && input_len < 19) {
                input_buf[input_len++] = '2';
                show_current_page();
            } else if (p.x >= BTN_3_X && p.x <= BTN_3_X + BTN_3_W && p.y >= BTN_3_Y && p.y <= BTN_3_Y + BTN_3_H && input_len < 19) {
                input_buf[input_len++] = '3';
                show_current_page();
            } else if (p.x >= BTN_4_X && p.x <= BTN_4_X + BTN_4_W && p.y >= BTN_4_Y && p.y <= BTN_4_Y + BTN_4_H && input_len < 19) {
                input_buf[input_len++] = '4';
                show_current_page();
            } else if (p.x >= BTN_5_X && p.x <= BTN_5_X + BTN_5_W && p.y >= BTN_5_Y && p.y <= BTN_5_Y + BTN_5_H && input_len < 19) {
                input_buf[input_len++] = '5';
                show_current_page();
            } else if (p.x >= BTN_6_X && p.x <= BTN_6_X + BTN_6_W && p.y >= BTN_6_Y && p.y <= BTN_6_Y + BTN_6_H && input_len < 19) {
                input_buf[input_len++] = '6';
                show_current_page();
            } else if (p.x >= BTN_7_X && p.x <= BTN_7_X + BTN_7_W && p.y >= BTN_7_Y && p.y <= BTN_7_Y + BTN_7_H && input_len < 19) {
                input_buf[input_len++] = '7';
                show_current_page();
            } else if (p.x >= BTN_8_X && p.x <= BTN_8_X + BTN_8_W && p.y >= BTN_8_Y && p.y <= BTN_8_Y + BTN_8_H && input_len < 19) {
                input_buf[input_len++] = '8';
                show_current_page();
            } else if (p.x >= BTN_9_X && p.x <= BTN_9_X + BTN_9_W && p.y >= BTN_9_Y && p.y <= BTN_9_Y + BTN_9_H && input_len < 19) {
                input_buf[input_len++] = '9';
                show_current_page();
            } else if (p.x >= BTN_0_X && p.x <= BTN_0_X + BTN_0_W && p.y >= BTN_0_Y && p.y <= BTN_0_Y + BTN_0_H && input_len < 19) {
                input_buf[input_len++] = '0';
                show_current_page();
            }
            // *键
            else if (p.x >= BTN_STAR_X && p.x <= BTN_STAR_X + BTN_STAR_W && 
                     p.y >= BTN_STAR_Y && p.y <= BTN_STAR_Y + BTN_STAR_H && input_len < 19) {
                input_buf[input_len++] = '*';
                show_current_page();
            }
            // #键
            else if (p.x >= BTN_SHARP_X && p.x <= BTN_SHARP_X + BTN_SHARP_W && 
                     p.y >= BTN_SHARP_Y && p.y <= BTN_SHARP_Y + BTN_SHARP_H && input_len < 19) {
                input_buf[input_len++] = '#';
                show_current_page();
            }
            // OK键
            else if (p.x >= BTN_OK_X && p.x <= BTN_OK_X + BTN_OK_W && p.y >= BTN_OK_Y && p.y <= BTN_OK_Y + BTN_OK_H) {
                printf("👉 确认输入：%s\n", input_buf);
                switch(current_input) {
                    case INPUT_USER_ID:
                        strcpy(user_id, input_buf);
                        current_page = PAGE_USER_LOGIN;
                        break;
                    case INPUT_USER_PWD:
                        strcpy(user_pwd, input_buf);
                        current_page = PAGE_USER_LOGIN;
                        break;
                    case INPUT_ADMIN_ID:
                        strcpy(admin_id, input_buf);
                        current_page = PAGE_ADMIN;
                        break;
                    case INPUT_ADMIN_PWD:
                        strcpy(admin_pwd, input_buf);
                        current_page = PAGE_ADMIN;
                        break;
                    default:
                        break;
                }
                show_current_page();
            }
            break;
        default:
            break;
    }
}

// ==================================================
// 设备初始化与资源释放
// ==================================================
int dev_init(void)
{
    // DRM显示初始化
	drm_fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
	if (drm_fd < 0) {
		printf("open drm device failed!\n");
        return -1;
	}
	DRMinit(drm_fd);
	DRMcreateFB(drm_fd, &drm);
	lcd_ptr = (uint32_t *)drm.vaddr;

    // 触摸屏初始化
	ts_fd = open("/dev/input/event2", O_RDONLY);
	if (ts_fd == -1) {
		perror("Failed to open touch device");
		return -1;
	}

    // 初始化互斥锁
    pthread_mutex_init(&cam_mutex, NULL);

	return 0;
}

void dev_uninit(void)
{
    // 停止摄像头线程
    camera_running = 0;
    usleep(200000);
    // 释放抓拍缓冲区
    if (snap_buf.start)
    {
        free(snap_buf.start);
        snap_buf.start = NULL;
    }
    // 销毁互斥锁
    pthread_mutex_destroy(&cam_mutex);
    // 触摸屏释放
	close(ts_fd);
    // DRM显示释放
	DRMfreeResources(drm_fd, &drm);
	close(drm_fd);
}

// ==================================================
// 主函数
// ==================================================
int main(void)
{
    if (dev_init() < 0) {
        dev_uninit();
        return -1;
    }
	show_current_page();

	while (1)
	{
		TouchPoint point = get_touch_data(ts_fd);
		if (point.valid)
		{
			printf("触摸坐标：X=%d, Y=%d\n", point.x, point.y);
			check_touch_buttons(point);
            usleep(100000);
		}
        usleep(10000);
	}
	dev_uninit();
	return 0;
}