#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
    // 1 打开 lcd 屏幕设备文件
    // 屏幕设备型号at070tn92 宽：1024，高：600
    
    int lcd_fd = open("/dev/fb0", O_RDWR);
    
    if (lcd_fd == -1)
    {
        printf("open txt file failed!\n");
        return -1;
    }
    
    // 2. open bmp file 1024 600 24 1.bmp
    
    int bmp_fd = open(pathname, O_RDWR);
    
    if (bmp_fd == -1)
    {
        printf("open bmp file failed!\n");
        return -1;
    }
    
    // 3. read bmp data
    
    char header[54] = {0};
    char rgb_buf[w * h * 3]; // 0~1024*600*3-1
    int argb_buf[1024 * 600];            // 0~1024*600-1
    read(bmp_fd, header, 54);
    read(bmp_fd, rgb_buf, w * h * 3);
    
    int i, j;
    int r, g, b;
    int color;
    
    // 4. datas
    
    for (j = 0; j < h; j++)
    {
        for (i = 0; i < w; i++)
        {
            // 提取蓝色
            b = rgb_buf[(w * j + i) * 3 + 0];
            // 绿色和红色以此类推
            g = rgb_buf[(w * j + i) * 3 + 1];
            r = rgb_buf[(w * j + i) * 3 + 2];
            // 位移动数据到正确的位置上
            color = b | g << 8 | r << 16 | 0 << 24; // ARGB
            argb_buf[1024 * (h - 1 - j+y) + i+x] = color;
        }
    } 
    
    // 5. 将颜色数据显示lcd屏幕上
    
    write(lcd_fd, argb_buf, 1024 * 600 * 4);
    
    // 6. 关闭文件
    close(lcd_fd);
    close(bmp_fd);
}

int main(void)
{
	lcd_draw_bmp("2.bmp", 300, 50, 300, 300);
	lcd_draw_bmp("11.bmp", 300, 380, 309, 86);
	return 0;
}