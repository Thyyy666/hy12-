#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#define WIDTH  1024
#define HEIGHT 600
#define PI     3.141592653589793

// MC风格颜色定义（精准还原游戏色值）
#define SKY_BLUE    0x0087CEEB  // MC天空淡蓝色
#define GRASS_GREEN 0x0070B93C  // 草地主绿色
#define DIRT_BROWN  0x008B5A2B  // 泥土棕色
#define CHICK_BODY  0x00E8E8E8  // 小鸡身体浅灰白
#define BEAK_BROWN  0x00D4A046  // 鸡嘴土黄色
#define WATTLE_RED  0x00FF3030  // 鸡冠/肉垂红色
#define EYE_BLACK   0x00000000  // 眼睛纯黑
#define LEG_YELLOW  0x00E6C260  // 鸡脚浅黄色

int argb_buf[WIDTH * HEIGHT];

// 画实心圆（保留原有函数，兼容之前的代码结构）
void draw_circle(int cx, int cy, int r, int color)
{
    int x, y;
    for (y = cy - r; y <= cy + r; y++) {
        if (y < 0 || y >= HEIGHT) continue;
        for (x = cx - r; x <= cx + r; x++) {
            if (x < 0 || x >= WIDTH) continue;
            int dx = x - cx;
            int dy = y - cy;
            if (dx*dx + dy*dy <= r*r) {
                argb_buf[y * WIDTH + x] = color;
            }
        }
    }
}

// 画实心矩形（MC方块核心绘制函数，完美还原像素风格）
void draw_rect(int x0, int y0, int w, int h, int color)
{
    int x, y;
    for (y = y0; y < y0 + h; y++) {
        if (y < 0 || y >= HEIGHT) continue;
        for (x = x0; x < x0 + w; x++) {
            if (x < 0 || x >= WIDTH) continue;
            argb_buf[y * WIDTH + x] = color;
        }
    }
}

// 画椭圆（保留原有函数，兼容结构）
void draw_ellipse(int cx, int cy, int rx, int ry, int color)
{
    int x, y;
    for (y = cy - ry; y <= cy + ry; y++) {
        if (y < 0 || y >= HEIGHT) continue;
        for (x = cx - rx; x <= cx + rx; x++) {
            if (x < 0 || x >= WIDTH) continue;
            double dx = (double)(x - cx) / rx;
            double dy = (double)(y - cy) / ry;
            if (dx*dx + dy*dy <= 1.0) {
                argb_buf[y * WIDTH + x] = color;
            }
        }
    }
}

int main(void)
{
    int lcd_fd = open("/dev/fb0", O_RDWR);
    if (lcd_fd == -1) {
        perror("open /dev/fb0 failed");
        return -1;
    }

    // 1. 绘制MC风格背景（天空+草地，还原游戏场景）
    memset(argb_buf, 0, sizeof(argb_buf));
    // 上半部分天空
    draw_rect(0, 0, WIDTH, HEIGHT/2, SKY_BLUE);
    // 下半部分草地
    draw_rect(0, HEIGHT/2, WIDTH, HEIGHT/2, GRASS_GREEN);
    // 草地像素方块细节（还原MC质感）
    for (int i = 0; i < WIDTH; i += 40) {
        for (int j = HEIGHT/2; j < HEIGHT; j += 40) {
            if ((i+j) % 80 == 0) {
                draw_rect(i, j, 40, 40, 0x0067A936);
            }
        }
    }

    // 小鸡中心坐标（屏幕正中间，放大显示）
    int cx = WIDTH / 2;
    int cy = HEIGHT / 2;

    // 2. 绘制小鸡身体（MC方块结构，从下到上绘制保证层级正确）
    // 鸡脚（左右两个）
    draw_rect(cx - 35, cy + 180, 25, 80, LEG_YELLOW);
    draw_rect(cx + 10, cy + 180, 25, 80, LEG_YELLOW);
    // 鸡脚底座
    draw_rect(cx - 50, cy + 260, 55, 15, LEG_YELLOW);
    draw_rect(cx - 5, cy + 260, 55, 15, LEG_YELLOW);

    // 身体主体
    draw_rect(cx - 90, cy + 20, 180, 160, CHICK_BODY);
    // 身体尾部
    draw_rect(cx + 90, cy + 40, 60, 120, CHICK_BODY);

    // 头部（放大版，占满屏幕核心位置）
    draw_rect(cx - 110, cy - 180, 220, 200, CHICK_BODY);

    // 鸡嘴（黄色方块）
    draw_rect(cx - 130, cy - 120, 120, 90, BEAK_BROWN);
    // 肉垂（红色方块，嘴下方）
    draw_rect(cx - 90, cy - 30, 80, 70, WATTLE_RED);

    // 眼睛（黑色方块，左右各一个）
    draw_rect(cx - 80, cy - 140, 35, 45, EYE_BLACK);
    draw_rect(cx + 10, cy - 140, 35, 45, EYE_BLACK);

    // 3. 写入屏幕显示
    write(lcd_fd, argb_buf, WIDTH * HEIGHT * 4);
    close(lcd_fd);

    printf("Minecraft小鸡绘制完成！\n");
    return 0;
}