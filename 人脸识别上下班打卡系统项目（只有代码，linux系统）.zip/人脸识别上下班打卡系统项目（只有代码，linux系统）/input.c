#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include "jpeglib.h"
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include "DRMwrap.h"
#include <stdlib.h>
#include <dirent.h>
#include <linux/input.h>
#include <stdbool.h>

int drm_fd = -1, ts_fd = -1;
struct drmHandle drm;
uint32_t *lcd_ptr = NULL;

// 按钮区域定义（左右各200×100）
#define BTN_W 200
#define BTN_H 100
#define BTN1_X 150      // 左按钮X
#define BTN1_Y 250      // 左按钮Y
#define BTN2_X (1024 - 150 - BTN_W) // 右按钮X
#define BTN2_Y 250      // 右按钮Y

// 触摸点
typedef struct
{
	int x, y, pressure;
	bool valid;
} TouchPoint;

// 获取触摸数据
TouchPoint get_touch_data(int fd)
{
	struct input_event ev;
	static TouchPoint point = {0};
	point.valid = false;

	while (read(fd, &ev, sizeof(ev)) == sizeof(ev))
	{
		switch (ev.type)
		{
		case EV_ABS:
			if (ev.code == ABS_X) point.x = ev.value;
			if (ev.code == ABS_Y) point.y = ev.value;
			if (ev.code == ABS_PRESSURE) point.pressure = ev.value;
			break;
		case EV_KEY:
			if (ev.code == BTN_TOUCH && ev.value == 0)
			{
				point.valid = true;
				return point;
			}
			break;
		}
	}
	return (TouchPoint){0};
}

// ==============================
// 你原有 JPEG 解码代码（完全不动）
// ==============================
struct my_error_mgr
{
	struct jpeg_error_mgr pub;
	jmp_buf setjmp_buffer;
};
typedef struct my_error_mgr *my_error_ptr;

METHODDEF(void) my_error_exit(j_common_ptr cinfo)
{
	my_error_ptr myerr = (my_error_ptr)cinfo->err;
	(*cinfo->err->output_message)(cinfo);
	longjmp(myerr->setjmp_buffer, 1);
}

GLOBAL(int) read_JPEG_file(const char *filename, int *image_width, int *image_height, char **out_buffer)
{
	struct jpeg_decompress_struct cinfo;
	struct my_error_mgr jerr;
	FILE *infile;
	JSAMPARRAY buffer;
	int row_stride;

	if ((infile = fopen(filename, "rb")) == NULL)
	{
		fprintf(stderr, "can't open %s\n", filename);
		return 0;
	}

	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = my_error_exit;
	if (setjmp(jerr.setjmp_buffer))
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return 0;
	}

	jpeg_create_decompress(&cinfo);
	jpeg_stdio_src(&cinfo, infile);
	jpeg_read_header(&cinfo, TRUE);
	*image_width = cinfo.image_width;
	*image_height = cinfo.image_height;
	jpeg_start_decompress(&cinfo);

	row_stride = cinfo.output_width * cinfo.output_components;
	buffer = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, row_stride, 1);
	*out_buffer = calloc(1, row_stride * cinfo.output_height);
	char *dst = *out_buffer;

	while (cinfo.output_scanline < cinfo.output_height)
	{
		jpeg_read_scanlines(&cinfo, buffer, 1);
		memcpy(dst, buffer[0], row_stride);
		dst += row_stride;
	}

	jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);
	fclose(infile);
	return 1;
}

int jpeg_to_lcd(int x, int y, int w, int h, char *jpeg_buffer)
{
	int i, j, r, g, b, color;
	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			r = jpeg_buffer[(w * j + i) * 3 + 0];
			g = jpeg_buffer[(w * j + i) * 3 + 1];
			b = jpeg_buffer[(w * j + i) * 3 + 2];
			color = b | g << 8 | r << 16;
			lcd_ptr[1024 * (j + y) + i + x] = color;
		}
	}
	DRMshowUp(drm_fd, &drm);
	return 0;
}

int lcd_draw_jpeg(const char *pathname, int x, int y)
{
	char *jpeg_buffer;
	int w, h;
	if (!read_JPEG_file(pathname, &w, &h, &jpeg_buffer)) return -1;
	jpeg_to_lcd(x, y, w, h, jpeg_buffer);
	free(jpeg_buffer);
	return 0;
}

// ==============================
// BMP 显示（你原有代码）
// ==============================
int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
	int bmp_fd = open(pathname, O_RDONLY);
	if (bmp_fd < 0) return -1;

	char header[54] = {0};
	char rgb_buf[w * h * 3];
	read(bmp_fd, header, 54);
	read(bmp_fd, rgb_buf, w * h * 3);

	int i, j, r, g, b, color;
	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			b = rgb_buf[(w * j + i) * 3 + 0];
			g = rgb_buf[(w * j + i) * 3 + 1];
			r = rgb_buf[(w * j + i) * 3 + 2];
			color = b | g << 8 | r << 16 | 0 << 24;
			lcd_ptr[1024 * (h - 1 - j + y) + i + x] = color;
		}
	}
	DRMshowUp(drm_fd, &drm);
	close(bmp_fd);
	return 0;
}

// ==============================
// 【新增】全屏显示 BMP（1024×600）
// ==============================
void show_fullscreen_bmp(const char *path)
{
	lcd_draw_bmp(path, 0, 0, 1024, 600);
}

// ==============================
// 【核心】显示两个按钮（左右200×100）
// ==============================
void show_two_buttons(void)
{
	// 左边按钮：btn_left.bmp   200×100
	lcd_draw_bmp("dl.bmp",  BTN1_X, BTN1_Y, 200, 100);

	// 右边按钮：btn_right.bmp  200×100
	lcd_draw_bmp("lk.bmp", BTN2_X, BTN2_Y, 200, 100);
}

// ==============================
// 【核心】触摸判断（点击左右按钮）
// ==============================
void check_touch_buttons(TouchPoint p)
{
	// 点击 左按钮
	if (p.x >= BTN1_X && p.x <= BTN1_X + BTN_W &&
		p.y >= BTN1_Y && p.y <= BTN1_Y + BTN_H)
	{
		printf("👉 点击左按钮 → 显示全屏图1\n");
		show_fullscreen_bmp("dlym.bmp");
	}

	// 点击 右按钮
	else if (p.x >= BTN2_X && p.x <= BTN2_X + BTN_W &&
			 p.y >= BTN2_Y && p.y <= BTN2_Y + BTN_H)
	{
		printf("👉 点击右按钮 → 显示全屏图2\n");
		show_fullscreen_bmp("lkym.bmp");
	}
}

// ==============================
// 设备初始化（你原有代码）
// ==============================
int dev_init(void)
{
	drm_fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
	DRMinit(drm_fd);
	DRMcreateFB(drm_fd, &drm);
	lcd_ptr = (uint32_t *)drm.vaddr;

	ts_fd = open("/dev/input/event2", O_RDONLY);
	if (ts_fd == -1) perror("touch open failed");
	return 0;
}

void dev_uninit(void)
{
	close(ts_fd);
	DRMfreeResources(drm_fd, &drm);
	close(drm_fd);
}

// ==============================
// 主函数（完美逻辑）
// ==============================
int main(void)
{
	dev_init();
	show_two_buttons(); // 开机显示两个按钮

	while (1)
	{
		TouchPoint point = get_touch_data(ts_fd);
		if (point.valid)
		{
			check_touch_buttons(point); // 判断点击哪个按钮
			usleep(200000); // 消抖
			show_two_buttons(); // 显示回到按钮界面
		}
	}

	dev_uninit();
	return 0;
}