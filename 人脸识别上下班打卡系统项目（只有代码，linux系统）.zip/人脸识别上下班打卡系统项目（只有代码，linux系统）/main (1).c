#include <dirent.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "camera_capture_yuyv.h"
#include "DRMwrap.h"
#include "image.h"
#include "jpeglib.h"
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <setjmp.h>
#include <linux/input.h>
#include <string.h>
#include <pthread.h>

int snap_flag = 0, camera_flag = 0, record_flag = 0;
int drm_fd = -1, ts_fd = -1, camera_fd = -1;
struct buffer jpeg_buf;
struct drmHandle drm;
uint32_t *lcd_ptr = NULL;

// 定义触摸点结构体
typedef struct
{
	int x;		  // X坐标
	int y;		  // Y坐标
	int pressure; // 触摸压力
	bool valid;	  // 有效标志位
} TouchPoint;

int jpeg_to_lcd(int x, int y, int w, int h, char *jpeg_buffer)
{
	int i, j;
	int r, g, b;
	int color;

	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			// 提取蓝色
			r = jpeg_buffer[(w * j + i) * 3 + 0];
			// 绿色和红色以此类推
			g = jpeg_buffer[(w * j + i) * 3 + 1];
			b = jpeg_buffer[(w * j + i) * 3 + 2];
			// 位移动数据到正确的位置上
			// color = b;
			// color |= g << 8;
			// color |= r << 16;   // color += r <<16;
			color = b | g << 8 | r << 16;
			lcd_ptr[1024 * (j + y) + i + x] = color;
		}
	}

	DRMshowUp(drm_fd, &drm);

	// write(lcd_fd, argb_buf, 1024 * 600 * 4);
	return 0;
}

struct my_error_mgr
{
	struct jpeg_error_mgr pub; /* "public" fields */

	jmp_buf setjmp_buffer; /* for return to caller */
};

typedef struct my_error_mgr *my_error_ptr;

/*
 * Here's the routine that will replace the standard error_exit method:
 */

METHODDEF(void)
my_error_exit(j_common_ptr cinfo)
{
	/* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
	my_error_ptr myerr = (my_error_ptr)cinfo->err;

	/* Always display the message. */
	/* We could postpone this until after returning, if we chose. */
	(*cinfo->err->output_message)(cinfo);

	/* Return control to the setjmp point */
	longjmp(myerr->setjmp_buffer, 1);
}

int jpg_to_rgb(unsigned char *jpg_buffer, size_t jpg_size, struct image_info *minfo, int zoom_flag)
{
	struct jpeg_decompress_struct cinfo;
	struct my_error_mgr jerr;

	// 初始化 JPEG 解码结构
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = my_error_exit;

	if (setjmp(jerr.setjmp_buffer))
	{
		jpeg_destroy_decompress(&cinfo);
		return -1;
	}

	jpeg_create_decompress(&cinfo);

	// 将 JPEG 数据源设置为内存中的数据
	jpeg_mem_src(&cinfo, jpg_buffer, jpg_size);

	// 读取 JPEG 头部并检查格式
	if (jpeg_read_header(&cinfo, TRUE) != 1)
	{
		fprintf(stderr, "JPEG header read failed: %s\n", strerror(errno));
		return -1;
	}

	cinfo.scale_num = 1;		   // 分子
	cinfo.scale_denom = zoom_flag; // 分母

	// 开始解码
	jpeg_start_decompress(&cinfo);

	minfo->width = cinfo.output_width;
	minfo->height = cinfo.output_height;
	int row_stride = cinfo.output_width * cinfo.output_components;

	// 分配 RGB 缓冲区
	minfo->rgb = calloc(1, cinfo.output_height * row_stride);
	if (!minfo->rgb)
	{
		fprintf(stderr, "Memory allocation failed.\n");
		jpeg_destroy_decompress(&cinfo);
		return -1;
	}

	// 逐行读取并解码 JPEG 数据
	while (cinfo.output_scanline < cinfo.output_height)
	{
		unsigned char *buffer_array[1];
		buffer_array[0] = (unsigned char *)(minfo->rgb + (cinfo.output_scanline) * row_stride);
		jpeg_read_scanlines(&cinfo, buffer_array, 1);
	}

	// 完成解码并释放资源
	jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);

	return 0;
}

// 从文件读取 JPEG 数据并调用 jpg_to_rgb
void load_jpeg_from_file(const char *jpgfile, struct image_info *minfo, int zoom_flag)
{
	struct stat file_info;
	if (stat(jpgfile, &file_info) == -1)
	{
		fprintf(stderr, "Failed to stat file: %s\n", jpgfile);
		return;
	}

	int fd = open(jpgfile, O_RDONLY);
	if (fd == -1)
	{
		fprintf(stderr, "Failed to open file: %s\n", jpgfile);
		return;
	}

	unsigned char *jpg_buffer = (unsigned char *)calloc(1, file_info.st_size);
	if (!jpg_buffer)
	{
		fprintf(stderr, "Memory allocation failed.\n");
		close(fd);
		return;
	}

	ssize_t nread = read(fd, jpg_buffer, file_info.st_size);
	close(fd);
	if (nread <= 0)
	{
		free(jpg_buffer);
		fprintf(stderr, "Failed to read JPEG data from file.\n");
		return;
	}

	jpg_to_rgb(jpg_buffer, nread, minfo, zoom_flag);
	free(jpg_buffer);
}

int lcd_draw_jpeg(int x, int y, const char *pathname, unsigned char *jpeg_buffer, long unsigned int jpeg_size, struct drmHandle *drm, int zoom_flag)
{
	struct image_info *minfo = (struct image_info *)calloc(1, sizeof(struct image_info));

	if (!minfo)
	{
		fprintf(stderr, "Memory allocation failed for image_info.\n");
		return -1;
	}

	if (jpeg_buffer && jpeg_size > 0)
	{
		// 使用传入的 JPEG 数据缓冲区
		if (jpg_to_rgb(jpeg_buffer, jpeg_size, minfo, zoom_flag) != 0)
		{
			free(minfo);
			return -1;
		}
	}
	else if (pathname)
	{
		// 从文件读取 JPEG 数据
		load_jpeg_from_file(pathname, minfo, zoom_flag);
		if (!minfo->rgb)
		{
			free(minfo);
			return -1;
		}
	}
	else
	{
		fprintf(stderr, "No valid JPEG data or path provided.\n");
		free(minfo);
		return -1;
	}

	// 将rgb数据显示出来
	int i, j;
	for (j = 0; j < (drm->height) && j < minfo->height; j++)
	{
		for (i = 0; i < (drm->width) && i < minfo->width; i++)
		{
			memcpy(drm->vaddr + 4 * (i + x) + drm->width * 4 * (j + y) + 0, minfo->rgb + 3 * i + minfo->width * 3 * j + 2, 1);
			memcpy(drm->vaddr + 4 * (i + x) + drm->width * 4 * (j + y) + 1, minfo->rgb + 3 * i + minfo->width * 3 * j + 1, 1);
			memcpy(drm->vaddr + 4 * (i + x) + drm->width * 4 * (j + y) + 2, minfo->rgb + 3 * i + minfo->width * 3 * j + 0, 1);
		}
	}
	DRMshowUp(drm_fd, drm);

	// 清理资源
	free(minfo->rgb);
	free(minfo);

	return 0;
}

int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
	// 1 打开 lcd 屏幕设备文件
	// 屏幕设备型号at070tn92 宽：1024，高：600

	// 2. open bmp file 1024 600 24 1.bmp

	int bmp_fd = open(pathname, O_RDWR);

	if (bmp_fd == -1)
	{
		printf("open bmp file failed!\n");
		return -1;
	}

	// 3. read bmp data

	char header[54] = {0};
	char rgb_buf[w * h * 3]; // 0~1024*600*3-1
	read(bmp_fd, header, 54);
	read(bmp_fd, rgb_buf, w * h * 3);

	int i, j;
	int r, g, b;
	int color;

	// 4. datas

	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			// 提取蓝色
			b = rgb_buf[(w * j + i) * 3 + 0];
			// 绿色和红色以此类推
			g = rgb_buf[(w * j + i) * 3 + 1];
			r = rgb_buf[(w * j + i) * 3 + 2];
			// 位移动数据到正确的位置上
			color = b | g << 8 | r << 16 | 0 << 24; // ARGB
			lcd_ptr[1024 * (h - 1 - j + y) + i + x] = color;
		}
	}

	DRMshowUp(drm_fd, &drm);

	// 5. 将颜色数据显示lcd屏幕上

	// write(lcd_fd, argb_buf, 1024 * 600 * 4);

	// 6. 关闭文件
	close(bmp_fd);

	return 0;
}

// 实时监控函数
void *read_camera_data(void *arg)
{
	pthread_detach(pthread_self());

	char pic_name[20];

	static int jpg_num = 0;
	snap_flag = 0;
	camera_flag = 0;

	while (1)
	{
		if (camera_flag == 1)
		{
			// 3，获取摄像头捕捉的画面
			camera_capture_get_frame(&jpeg_buf);

			// 4, yuyv格式转换jpeg
			yuyv2jpeg(jpeg_buf.start, jpeg_buf.length, 99);

			// 5，显示摄像头捕捉的画面
			lcd_draw_jpeg(0, 0, NULL, jpeg_buf.start, jpeg_buf.length, &drm, 1);

			// 5，如果点击抓拍，保存图片信息
			if (snap_flag == 1)
			{

				// 创建一个新的文件
				bzero(pic_name, 20);

				sprintf(pic_name, "%d.jpg", jpg_num);

				int pic_fd = open(pic_name, O_RDWR | O_CREAT, 0777);

				if (-1 == pic_fd)
				{
					perror("create jpg failed");
					continue;
				}

				write(pic_fd, jpeg_buf.start, jpeg_buf.length);

				close(pic_fd);
				lcd_draw_jpeg(0, 0, NULL, jpeg_buf.start, jpeg_buf.length, &drm, 8);
				snap_flag = 0;
			}
		}

		else if (camera_flag == 3) // 6，退出
		{
			break;
		}
	}

	pthread_exit(NULL);
}

void login_interface()
{
	// 背景 1024 600
	lcd_draw_jpeg(0, 0, "backgroud.jpg", NULL, 0, &drm, 1);

	// 图标：输入框， 300 50，数据域 300 400
	lcd_draw_jpeg(362, 50, "inputs.jpg", NULL, 0, &drm, 1);
	lcd_draw_jpeg(362, 150, "datas.jpg", NULL, 0, &drm, 1);
}

void main_interface()
{
	// 背景 1024 600
	lcd_draw_jpeg(0, 0, "backgroud.jpg", NULL, 0, &drm, 1);

	// 图标：用户， 200 80，管理 200 80，退出 200 80
	lcd_draw_jpeg(412, 146, "user.jpg", NULL, 0, &drm, 1);
	lcd_draw_jpeg(412, 306, "admin.jpg", NULL, 0, &drm, 1);
	lcd_draw_jpeg(10, 10, "quit.jpg", NULL, 0, &drm, 1);
}

// 获取一个完整触摸点
TouchPoint get_touch_data(int fd)
{
	struct input_event ev;
	static TouchPoint point = {0};

	point.valid = false;

	while (read(fd, &ev, sizeof(ev)) == sizeof(ev))
	{
		switch (ev.type)
		{
		case EV_ABS:
			switch (ev.code)
			{
			case ABS_X:
				point.x = ev.value;
				break;
			case ABS_Y:
				point.y = ev.value;
				break;
			case ABS_PRESSURE:
				point.pressure = ev.value;
				break;
			}
			break;

		case EV_KEY:
			if (ev.code == BTN_TOUCH && ev.value == 0)
			{
				// 触摸抬起时，标记数据有效
				point.valid = true;
				return point;
			}
			break;
		}
	}

	return (TouchPoint){0}; // 错误或中断返回
}

void login_function()
{
	char passwd[] = "12345678";
	char str[10] = {0};
	int count = 0;

	printf("main Touch screen device opened successfully.\n");
	printf("main Start reading touch data...\n\n");

	while (1)
	{
		TouchPoint point = get_touch_data(ts_fd);

		if (point.valid)
		{
			printf("Touch Point: X=%d, Y=%d, Pressure=%d\n",
				   point.x, point.y, point.pressure);

			if (point.pressure == 0)
			{
				printf("Touch released\n");
			}

			// 0 1~9的判断逻辑是一样
			if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '0';

				if (count == 8)
					count = 8;
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);

				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '1';
				if (count == 8)
					count = 8;
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '2';

				if (count == 8)
					count = 8;
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '3';
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '4';

				if (count == 8)
					count = 8;
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '5';
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '6';

				if (count == 8)
					count = 8;
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '7';
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '8';

				if (count == 8)
					count = 8;
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				str[count] = '9';
				// * 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "passwd.jpg", NULL, 0, &drm, 1);
				count++;
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{ // 删除
				count--;
				if (count == -1)
					count = 0;
				str[count] = '\0';
				// 输入框背景色 的显示 30 30
				lcd_draw_jpeg(372 + 30 * count, 60, "input_backgournd.jpg", NULL, 0, &drm, 1);
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226 && count == 8)
			{
				if (!strncmp(str, passwd, 8))
				{
					// 奶龙笑脸
					break;
				}
				else
				{
					// 奶龙鬼脸
					count = 0;
					memset(str, 0, sizeof(str));
					continue;
				}
			}
		}
	}
}

void user_interface()
{
	// 用户界面背景 1024 600
	lcd_draw_jpeg(0, 0, "user_bg.jpg", NULL, 0, &drm, 1);
}

void user_function();

void user_function()
{
	// 创建一条线程实时监控
	pthread_t camera_tid;
	pthread_create(&camera_tid, NULL, read_camera_data, NULL);

	while (1)
	{
		TouchPoint point = get_touch_data(ts_fd);

		if (point.valid)
		{
			printf("Touch Point: X=%d, Y=%d, Pressure=%d\n",
				   point.x, point.y, point.pressure);

			if (point.pressure == 0)
			{
				printf("Touch released\n");
			}

			if (point.x >= 10 && point.x < 210 && point.y >= 10 && point.y < 90)
			{
				// 开启摄像头标记设置（camera_flag = ?），抓拍标记设置（snap_flag = ?）
				printf("上班打卡\n");camera_flag = 1; snap_flag = 1;
			}
			else if (point.x >= 10 && point.x < 210 && point.y >= 10 && point.y < 90)
			{
				// 开启摄像头标记设置（camera_flag = ?）抓拍标记设置（snap_flag = ?）
				printf("下班打卡\n"); camera_flag = 1; snap_flag = 1;

			}
			else if (point.x >= 10 && point.x < 210 && point.y >= 10 && point.y < 90)
			{
				// 退出时需要设置摄像头退出标记（camera_flag = ?）
				camera_flag = 3;
				sleep(3);
				break;
			}
		}
	}
}

void admin_function()
{
	while (1)
	{
		TouchPoint point = get_touch_data(ts_fd);

		if (point.valid)
		{
			printf("Touch Point: X=%d, Y=%d, Pressure=%d\n",
				   point.x, point.y, point.pressure);

			if (point.pressure == 0)
			{
				printf("Touch released\n");
			}

			if (point.x >= 10 && point.x < 210 && point.y >= 10 && point.y < 90)
			{
			}
			else if (point.x >= 10 && point.x < 210 && point.y >= 10 && point.y < 90)
			{
			}
			else if (point.x >= 10 && point.x < 210 && point.y >= 10 && point.y < 90)
			{
				break;
			}
		}
	}
}

void admin_interface()
{
	// 管理界面背景 1024 600
	lcd_draw_jpeg(0, 0, "admin_bg.jpg", NULL, 0, &drm, 1);
}

void main_function()
{
	printf("main Touch screen device opened successfully.\n");
	printf("main Start reading touch data...\n\n");

	while (1)
	{
		main_interface();
		TouchPoint point = get_touch_data(ts_fd);

		if (point.valid)
		{
			printf("Touch Point: X=%d, Y=%d, Pressure=%d\n",
				   point.x, point.y, point.pressure);

			if (point.pressure == 0)
			{
				printf("Touch released\n");
			}

			// 用户管理，管理员，退出 200 80
			if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				user_interface();
				user_function();
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				admin_interface();
				admin_function();
			}
			else if (point.x >= 412 && point.x < 612 && point.y >= 146 && point.y < 226)
			{
				break;
			}
		}
	}
}

int read_dir_files(const char *dir_path, char *file_type, char (*file_names)[256], int *file_count)
{
	// 1. 打开目录
	DIR *dir = opendir(dir_path);
	if (dir == NULL)
	{
		printf("Failed to open directory: %s\n", dir_path);
		return -1;
	}

	int index = *file_count;

	struct dirent *entry;

	char full_path[512];

	// 2. 读取目录中的文件
	while (1)
	{
		entry = readdir(dir);
		if (entry == NULL)
		{
			*file_count = index;
			break; // 读取完毕
		}
		if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
		{
			continue; // 跳过当前目录和父目录
		}

		// 构建完整的文件路径

		sprintf(full_path, "%s/%s", dir_path, entry->d_name);

		// 3. 判断是否为普通文件
		if (entry->d_type == DT_REG)
		{
			if (strncmp(entry->d_name + strlen(entry->d_name) - strlen(file_type), file_type, strlen(file_type)) == 0)
			{
				// 将文件名保存到数组中
				strcpy(file_names[index], full_path);
				index++;
			}
		}
	}

	// 4. 关闭目录
	closedir(dir);

	return 0;
}

int dev_init(void)
{
	// 1. 打开 drm 屏幕设备
	drm_fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
	if (drm_fd == -1)
	{
		printf("open drm device failed!\n");
	}

	// 2. 初始化 drm 设备
	DRMinit(drm_fd);

	// 3. 创建帧缓冲区
	DRMcreateFB(drm_fd, &drm);

	// 4. 获取 lcd 映射内存地址
	lcd_ptr = (uint32_t *)drm.vaddr;

	// 5. 打开触摸屏设备
	const char *device_path = "/dev/input/event2"; // 修改为实际设备路径
	ts_fd = open(device_path, O_RDONLY);
	if (ts_fd == -1)
	{
		perror("Failed to open touch device");
		return 1;
	}

	// 6. 打开摄像头设备

	if (0 != (camera_capture_open(DEV_CAMERA)))
	{
		printf("linux v4l2 device open failed\n");
		return -4;
	}

	// 1，设备初始化

	camera_capture_init(&jpeg_buf);

	// 2，开启捕捉

	camera_capture_start_capturing();

	return 0;
}

void dev_uninit(void)
{
	camera_capture_stop_capturing();
	camera_capture_uninit(&jpeg_buf);
	camera_capture_close();
	close(ts_fd);
	// 1. 释放帧缓冲区
	DRMfreeResources(drm_fd, &drm);
	close(drm_fd);
}

int main(void)
{
	dev_init();

	while (1)
	{
		login_interface();

		login_function();

		main_interface();

		main_function();
	}

	getchar();

	dev_uninit();

	return 0;
}