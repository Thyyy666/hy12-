#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdio.h>
#include "jpeglib.h"
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include "DRMwrap.h"

int drm_fd = -1;

struct drmHandle drm;
uint32_t *lcd_ptr = NULL;

struct my_error_mgr
{
	struct jpeg_error_mgr pub; /* "public" fields */

	jmp_buf setjmp_buffer; /* for return to caller */
};

typedef struct my_error_mgr *my_error_ptr;

/*
 * Here's the routine that will replace the standard error_exit method:
 */

METHODDEF(void)
my_error_exit(j_common_ptr cinfo)
{
	/* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
	my_error_ptr myerr = (my_error_ptr)cinfo->err;

	/* Always display the message. */
	/* We could postpone this until after returning, if we chose. */
	(*cinfo->err->output_message)(cinfo);

	/* Return control to the setjmp point */
	longjmp(myerr->setjmp_buffer, 1);
}

/*
 * Sample routine for JPEG decompression.  We assume that the source file name
 * is passed in.  We want to return 1 on success, 0 on error.
 */

GLOBAL(int)
read_JPEG_file(const char *filename, int *image_width, int *image_height, char **out_buffer)
{
	/* This struct contains the JPEG decompression parameters and pointers to
	 * working space (which is allocated as needed by the JPEG library).
	 */
	struct jpeg_decompress_struct cinfo;
	/* We use our private extension JPEG error handler.
	 * Note that this struct must live as long as the main JPEG parameter
	 * struct, to avoid dangling-pointer problems.
	 */
	struct my_error_mgr jerr;
	/* More stuff */
	FILE *infile;	   /* source file */
	JSAMPARRAY buffer; /* Output row buffer */
	int row_stride;	   /* physical row width in output buffer */

	/* In this example we want to open the input file before doing anything else,
	 * so that the setjmp() error recovery below can assume the file is open.
	 * VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
	 * requires it in order to read binary files.
	 */

	if ((infile = fopen(filename, "rb")) == NULL)
	{
		fprintf(stderr, "can't open %s\n", filename);
		return 0;
	}

	/* Step 1: 分配并初始化解压对象 */

	/* We set up the normal JPEG error routines, then override error_exit. */
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = my_error_exit;
	/* Establish the setjmp return context for my_error_exit to use. */
	if (setjmp(jerr.setjmp_buffer))
	{
		/* If we get here, the JPEG code has signaled an error.
		 * We need to clean up the JPEG object, close the input file, and return.
		 */
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return 0;
	}
	/* Now we can initialize the JPEG decompression object. */
	jpeg_create_decompress(&cinfo);

	/* Step 2: 指定解压缩数据源 (eg, a file) */

	jpeg_stdio_src(&cinfo, infile);

	/* Step 3: 读取jpg文件头 */

	(void)jpeg_read_header(&cinfo, TRUE);
	/* We can ignore the return value from jpeg_read_header since
	 *   (a) suspension is not possible with the stdio data source, and
	 *   (b) we passed TRUE to reject a tables-only JPEG file as an error.
	 * See libjpeg.txt for more info.
	 */
	*image_width = cinfo.image_width;
	*image_height = cinfo.image_height;

	/* Step 4: 设置解压缩参数 */

	/* In this example, we don't need to change any of the defaults set by
	 * jpeg_read_header(), so we do nothing here.
	 */

	/* Step 5: 开启解压 */

	(void)jpeg_start_decompress(&cinfo);
	/* We can ignore the return value since suspension is not possible
	 * with the stdio data source.
	 */

	/* We may need to do some setup of our own at this point before reading
	 * the data.  After jpeg_start_decompress() we have the correct scaled
	 * output image dimensions available, as well as the output colormap
	 * if we asked for color quantization.
	 * In this example, we need to make an output work buffer of the right size.
	 */
	/* JSAMPLEs per row in output buffer */
	row_stride = cinfo.output_width * cinfo.output_components;
	/* Make a one-row-high sample array that will go away when done with image */
	buffer = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, row_stride, 1);
	*out_buffer = calloc(1, row_stride * cinfo.output_height);
	char *dst = *out_buffer;

	/* Step 6: 循环读取数据源 */

	/* Here we use the library's state variable cinfo.output_scanline as the
	 * loop counter, so that we don't have to keep track ourselves.
	 */
	while (cinfo.output_scanline < cinfo.output_height)
	{
		/* jpeg_read_scanlines expects an array of pointers to scanlines.
		 * Here the array is only one element long, but you could ask for
		 * more than one scanline at a time if that's more convenient.
		 */
		(void)jpeg_read_scanlines(&cinfo, buffer, 1);
		/* Assume put_scanline_someplace wants a pointer and sample count. */
		memcpy(dst, buffer[0], row_stride);
		dst += row_stride;
	}

	/* Step 7: 完成解压 */

	(void)jpeg_finish_decompress(&cinfo);
	/* We can ignore the return value since suspension is not possible
	 * with the stdio data source.
	 */

	/* Step 8: 释放资源 */

	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_decompress(&cinfo);

	/* After finish_decompress, we can close the input file.
	 * Here we postpone it until after no more JPEG errors are possible,
	 * so as to simplify the setjmp error logic above.  (Actually, I don't
	 * think that jpeg_destroy can do an error exit, but why assume anything...)
	 */
	fclose(infile);

	/* At this point you may want to check to see whether any corrupt-data
	 * warnings occurred (test whether jerr.pub.num_warnings is nonzero).
	 */

	/* And we're done! */
	return 1;
}

int jpeg_to_lcd(int x, int y, int w, int h, char *jpeg_buffer)
{
	int i, j;
	int r, g, b;
	int color;

	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			// 提取蓝色
			r = jpeg_buffer[(w * j + i) * 3 + 0];
			// 绿色和红色以此类推
			g = jpeg_buffer[(w * j + i) * 3 + 1];
			b = jpeg_buffer[(w * j + i) * 3 + 2];
			// 位移动数据到正确的位置上
			// color = b;
			// color |= g << 8;
			// color |= r << 16;   // color += r <<16;
			color = b | g << 8 | r << 16;
			lcd_ptr[1024 * (j + y) + i + x] = color;
		}
	}

	DRMshowUp(drm_fd, &drm);

	// write(lcd_fd, argb_buf, 1024 * 600 * 4);
	return 0;
}

int lcd_draw_jpeg(const char *pathname, int x, int y)
{

	char *jpeg_buffer;

	int image_width, image_height;

	if (read_JPEG_file(pathname, &image_width, &image_height, &jpeg_buffer) != 1)
	{
		fprintf(stderr, "Failed to read JPEG file: %s\n", pathname);
		return -1;
	}

	jpeg_to_lcd(x, y, image_width, image_height, jpeg_buffer);
	return 0;
}

int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
	// 1 打开 lcd 屏幕设备文件
	// 屏幕设备型号at070tn92 宽：1024，高：600

	// 2. open bmp file 1024 600 24 1.bmp

	int bmp_fd = open(pathname, O_RDWR);

	if (bmp_fd == -1)
	{
		printf("open bmp file failed!\n");
		return -1;
	}

	// 3. read bmp data

	char header[54] = {0};
	char rgb_buf[w * h * 3]; // 0~1024*600*3-1
	read(bmp_fd, header, 54);
	read(bmp_fd, rgb_buf, w * h * 3);

	int i, j;
	int r, g, b;
	int color;

	// 4. datas

	for (j = 0; j < h; j++)
	{
		for (i = 0; i < w; i++)
		{
			// 提取蓝色
			b = rgb_buf[(w * j + i) * 3 + 0];
			// 绿色和红色以此类推
			g = rgb_buf[(w * j + i) * 3 + 1];
			r = rgb_buf[(w * j + i) * 3 + 2];
			// 位移动数据到正确的位置上
			color = b | g << 8 | r << 16 | 0 << 24; // ARGB
			lcd_ptr[1024 * (h - 1 - j + y) + i + x] = color;
		}
	}

	DRMshowUp(drm_fd, &drm);

	// 5. 将颜色数据显示lcd屏幕上

	// write(lcd_fd, argb_buf, 1024 * 600 * 4);

	// 6. 关闭文件
	close(bmp_fd);
}

int dev_init(void)
{
	// 1. 打开 drm 屏幕设备
	drm_fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
	if (drm_fd == -1)
	{
		printf("open drm device failed!\n");
	}

	// 2. 初始化 drm 设备
	DRMinit(drm_fd);

	// 3. 创建帧缓冲区
	DRMcreateFB(drm_fd, &drm);

	// 4. 获取 lcd 映射内存地址
	lcd_ptr = (uint32_t *)drm.vaddr;

	return 0;
}

void dev_uninit(void)
{
	// 1. 释放帧缓冲区
	DRMfreeResources(drm_fd, &drm);
	close(drm_fd);
}

int main(void)
{
	dev_init();
	int m = 0;
while(1){
	lcd_draw_jpeg("1.jpg", 0, 0);
	usleep(100000);
	lcd_draw_jpeg("2.jpg", 0, 0);
	usleep(100000);
	lcd_draw_jpeg("3.jpg", 0, 0);
	usleep(100000);
	lcd_draw_jpeg("4.jpg", 0, 0);
	usleep(100000);
	lcd_draw_jpeg("5.jpg", 0, 0);
	usleep(100000);
	lcd_draw_jpeg("6.jpg", 0, 0);
    usleep(100000);
}
dev_uninit();
	return 0;
}
