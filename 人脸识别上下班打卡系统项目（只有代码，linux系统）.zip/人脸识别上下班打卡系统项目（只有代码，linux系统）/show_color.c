#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main(void)
{
	// 1,打开lcd屏幕设备文件
	// 屏幕设备型号at070tn92 宽：1024，高：600
	
	int txt_fd = open("/dev/fb0", O_RDWR);

	if (txt_fd == -1) {
		printf("open txt file failed!\n");
		return -1;
	}
	// 数据处理
	

	//设置颜色
	
	//以下为颜色的十六进制值，四字节对应的字节为
	//    透明度、  红、 绿、  蓝
	// 0x 00      00  00  ff;
	int color = 0x0000ff00;

	int argb_buf[1024*600];

	int i, j;

	/* 4000 = 5*1024 + 0 */
	/* 3000 = 3*1024 + 600 */

	//有多少行
	for (j = 0; j < 600; j++) {
		// 一行的数据有多少
		for (i = 0; i < 1024; i++) {
			argb_buf[1024*j+i] = color;
		}
	}

	//将颜色数据显示lcd屏幕上
	write(txt_fd, argb_buf, 1024*600*4);

	// 关闭文件
	int rt = close(txt_fd);

	if (rt == -1) {
		printf("close file failed!\n");
		return -1;
	}

	return 0;
}