﻿#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include "jpeglib.h"
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include "DRMwrap.h"
#include <dirent.h>
#include <linux/input.h>
#include <stdbool.h>
#include <pthread.h>
#include "camera_capture_yuyv.h"
#include "image.h"
#include "rockx/rockx.h"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <math.h>
#include <float.h>

// ===================== 宏定义 =====================
#define DEFAULT_USER_ID "1234"
#define DEFAULT_USER_PWD "1234"
#define DEFAULT_ADMIN_ID "1234"
#define DEFAULT_ADMIN_PWD "1234"

#define FACE_SIMILARITY_THRESHOLD 0.6f // 保留用于打卡比对
#define FACE_SIMILARITY_GAP 0.03f
#define FACE_CONFIDENCE_THRESHOLD 0.7f
#define CAMERA_WIDTH 640
#define CAMERA_HEIGHT 480
#define MAX_FACE_USER 999
#define FACE_MIN_SIZE 80
#define FACE_ALIGN_SIZE 112

#define CAM_PREVIEW_X 0
#define CAM_PREVIEW_Y 0
#define CAM_PREVIEW_W 640
#define CAM_PREVIEW_H 480
#define CAM_PREVIEW_ZOOM 1
#define SNAP_SHOW_X 680
#define SNAP_SHOW_Y 20
#define SNAP_SHOW_W 300
#define SNAP_SHOW_H 200
#define SNAP_SHOW_ZOOM 2

// 按钮参数
#define BTN_REG_FACE_IMG "lrrl.bmp"
#define BTN_REG_FACE_X 784
#define BTN_REG_FACE_Y 170
#define BTN_REG_FACE_W 220
#define BTN_REG_FACE_H 80
#define BTN_BACK4_IMG "fhen1.bmp"
#define BTN_BACK4_X 784
#define BTN_BACK4_Y 270
#define BTN_BACK4_W 220
#define BTN_BACK4_H 90
#define BTN_IN_IMG "sben.bmp"
#define BTN_IN_X 784
#define BTN_IN_Y 380
#define BTN_IN_W 220
#define BTN_IN_H 90
#define BTN_OUT_IMG "xben.bmp"
#define BTN_OUT_X 784
#define BTN_OUT_Y 490
#define BTN_OUT_W 220
#define BTN_OUT_H 90

// 页面背景参数
#define PAGE1_BG_IMG "xtjm.bmp"
#define PAGE1_BG_X 0
#define PAGE1_BG_Y 0
#define PAGE1_BG_W 1024
#define PAGE1_BG_H 600
#define PAGE2_BG_IMG "dljm.bmp"
#define PAGE2_BG_X 0
#define PAGE2_BG_Y 0
#define PAGE2_BG_W 1024
#define PAGE2_BG_H 600
#define PAGE3_BG_IMG "yhdl.bmp"
#define PAGE3_BG_X 0
#define PAGE3_BG_Y 0
#define PAGE3_BG_W 1024
#define PAGE3_BG_H 600
#define PAGE4_BG_IMG "glyjm.bmp"
#define PAGE4_BG_X 0
#define PAGE4_BG_Y 0
#define PAGE4_BG_W 1024
#define PAGE4_BG_H 600
#define PAGE5_BG_IMG "dljm.bmp"
#define PAGE5_BG_X 0
#define PAGE5_BG_Y 0
#define PAGE5_BG_W 1024
#define PAGE5_BG_H 600
#define PAGE6_BG_IMG "srjm.bmp"
#define PAGE6_BG_X 0
#define PAGE6_BG_Y 0
#define PAGE6_BG_W 1024
#define PAGE6_BG_H 600

// 通用按钮参数
#define BTN_ENTER_IMG "jrxten.bmp"
#define BTN_ENTER_X 312
#define BTN_ENTER_Y 450
#define BTN_ENTER_W 400
#define BTN_ENTER_H 100
#define BTN_BACK1_IMG "fhen.bmp"
#define BTN_BACK1_X 0
#define BTN_BACK1_Y 0
#define BTN_BACK1_W 280
#define BTN_BACK1_H 80
#define BTN_USER_IMG "yhdlen.bmp"
#define BTN_USER_X 212
#define BTN_USER_Y 150
#define BTN_USER_W 600
#define BTN_USER_H 150
#define BTN_ADMIN_IMG "glydlen.bmp"
#define BTN_ADMIN_X 212
#define BTN_ADMIN_Y 350
#define BTN_ADMIN_W 600
#define BTN_ADMIN_H 150
#define BTN_BACK2_IMG "fhen.bmp"
#define BTN_BACK2_X 0
#define BTN_BACK2_Y 0
#define BTN_BACK2_W 280
#define BTN_BACK2_H 80
#define BTN_SUBMIT_IMG "dlen.bmp"
#define BTN_SUBMIT_X 362
#define BTN_SUBMIT_Y 420
#define BTN_SUBMIT_W 300
#define BTN_SUBMIT_H 80
#define BTN_BACK3_IMG "fhen.bmp"
#define BTN_BACK3_X 0
#define BTN_BACK3_Y 0
#define BTN_BACK3_W 280
#define BTN_BACK3_H 80
#define BTN_EXIT_IMG "tcxten.bmp"
#define BTN_EXIT_X 824
#define BTN_EXIT_Y 0
#define BTN_EXIT_W 200
#define BTN_EXIT_H 80
#define BTN_REG_IMG "zcen.bmp"
#define BTN_REG_X 200
#define BTN_REG_Y 450
#define BTN_REG_W 200
#define BTN_REG_H 80
#define BTN_QUERY_IMG "cxlben.bmp"
#define BTN_QUERY_X 624
#define BTN_QUERY_Y 450
#define BTN_QUERY_W 200
#define BTN_QUERY_H 80

// 输入框坐标
#define USER_ID_X 320
#define USER_ID_Y 135
#define USER_ID_W 600
#define USER_ID_H 150
#define USER_PWD_X 320
#define USER_PWD_Y 320
#define USER_PWD_W 600
#define USER_PWD_H 100
#define ADMIN_ID_X 250
#define ADMIN_ID_Y 240
#define ADMIN_ID_W 600
#define ADMIN_ID_H 100
#define ADMIN_PWD_X 250
#define ADMIN_PWD_Y 360
#define ADMIN_PWD_W 600
#define ADMIN_PWD_H 100
#define INPUT_DISPLAY_X 100
#define INPUT_DISPLAY_Y 50
#define INPUT_DISPLAY_W 924
#define INPUT_DISPLAY_H 70

// 数字键盘坐标
#define BTN_1_X 40
#define BTN_1_Y 120
#define BTN_1_W 280
#define BTN_1_H 70
#define BTN_2_X 362
#define BTN_2_Y 120
#define BTN_2_W 280
#define BTN_2_H 70
#define BTN_3_X 684
#define BTN_3_Y 120
#define BTN_3_W 280
#define BTN_3_H 70
#define BTN_4_X 40
#define BTN_4_Y 215
#define BTN_4_W 280
#define BTN_4_H 70
#define BTN_5_X 362
#define BTN_5_Y 215
#define BTN_5_W 280
#define BTN_5_H 70
#define BTN_6_X 684
#define BTN_6_Y 215
#define BTN_6_W 280
#define BTN_6_H 70
#define BTN_7_X 40
#define BTN_7_Y 310
#define BTN_7_W 280
#define BTN_7_H 70
#define BTN_8_X 362
#define BTN_8_Y 310
#define BTN_8_W 280
#define BTN_8_H 70
#define BTN_9_X 684
#define BTN_9_Y 310
#define BTN_9_W 280
#define BTN_9_H 70
#define BTN_0_X 362
#define BTN_0_Y 405
#define BTN_0_W 280
#define BTN_0_H 70
#define BTN_STAR_X 40
#define BTN_STAR_Y 405
#define BTN_STAR_W 280
#define BTN_STAR_H 70
#define BTN_SHARP_X 684
#define BTN_SHARP_Y 405
#define BTN_SHARP_W 280
#define BTN_SHARP_H 70
#define BTN_OK_X 312
#define BTN_OK_Y 500
#define BTN_OK_W 400
#define BTN_OK_H 80

// 提示弹框图片
#define ERROR_IMG "cw.bmp"
#define ERROR_X 312
#define ERROR_Y 200
#define ERROR_W 400
#define ERROR_H 200
#define SUCCESS_IMG "success.bmp"
#define SUCCESS_X 312
#define SUCCESS_Y 200
#define SUCCESS_W 400
#define SUCCESS_H 200
#define FAIL_IMG "fail.bmp"
#define FAIL_X 312
#define FAIL_Y 200
#define FAIL_W 400
#define FAIL_H 200

// ===================== 全局变量 =====================
int drm_fd = -1, ts_fd = -1;
struct drmHandle drm;
uint32_t *lcd_ptr = NULL;

int camera_fd = -1;
int snap_flag = 0;
volatile int camera_running = 0;
struct buffer jpeg_buf;
struct buffer snap_buf;
pthread_t camera_tid;
pthread_mutex_t cam_mutex = PTHREAD_MUTEX_INITIALIZER;
static int clock_in_num = 0;
static int clock_out_num = 0;

typedef enum
{
    PAGE_HOME,
    PAGE_SELECT,
    PAGE_USER_LOGIN,
    PAGE_ADMIN,
    PAGE_CLOCK,
    PAGE_KEYBOARD,
    PAGE_ADMIN_FACE_REG
} PageState;
volatile PageState current_page = PAGE_HOME;

char input_buf[20] = {0};
int input_len = 0;
typedef enum
{
    INPUT_NONE,
    INPUT_USER_ID,
    INPUT_USER_PWD,
    INPUT_ADMIN_ID,
    INPUT_ADMIN_PWD
} InputType;
InputType current_input = INPUT_NONE;
char user_id[20] = {0};
char user_pwd[20] = {0};
char admin_id[20] = {0};
char admin_pwd[20] = {0};

// 人脸识别全局变量
rockx_handle_t face_det_handle;
rockx_handle_t face_5landmarks_handle;
rockx_handle_t face_recognize_handle;
char face_user_name[MAX_FACE_USER][20];
rockx_face_feature_t face_features[MAX_FACE_USER];
int people = 0;

volatile int get_face = 0;
volatile int take_face = 0;
char last_captured_face[200] = {0};
int show_captured_face = 0;

typedef struct
{
    int x, y, pressure;
    bool valid;
} TouchPoint;

// ===================== 函数声明 =====================
int extract_face_feature_from_image(rockx_image_t *src_image, rockx_face_feature_t *out_feature);
int extract_face_feature_from_box(rockx_image_t *src_image, rockx_rect_t *face_box, rockx_face_feature_t *out_feature);
int compare_face_with_database(rockx_face_feature_t *target_feature, char **matched_name, float *max_similarity);
int crop_face_from_image(rockx_image_t *src_img, rockx_rect_t *face_box, rockx_image_t *dst_img);

int init_face(void);
void register_face(rockx_image_t *full_image, rockx_rect_t *face_box);
void punch_in(rockx_face_feature_t *feature, rockx_image_t *cropped_face);
void punch_out(rockx_face_feature_t *feature, rockx_image_t *cropped_face);
rockx_object_t *get_valid_max_face(rockx_object_array_t *face_array);

void lcd_draw_rectangle(int x, int y, int w, int h, uint32_t color, int line_width);
void lcd_force_clear_screen(void);
void save_current_frame_to_file(rockx_image_t *image, const char *path);
void show_current_page(void);
void check_touch_buttons(TouchPoint p);
TouchPoint get_touch_data(int fd);
int send_msg(char *ip, short port, char *msg);
int dev_init(void);
void dev_uninit(void);
int lcd_draw_jpeg(int x, int y, const char *pathname, unsigned char *jpeg_buffer, long unsigned int jpeg_size, struct drmHandle *drm, int zoom_flag);
int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h);
void lcd_draw_digit(int x, int y, char c, uint32_t color);
void lcd_draw_number(int x, int y, const char *num, uint32_t color);
void *clock_camera_thread(void *arg);

// ===================== 工具函数 =====================
static float clamp01(float value)
{
    if (value < 0.0f)
        return 0.0f;
    if (value > 1.0f)
        return 1.0f;
    return value;
}

static float distance_to_similarity(float distance)
{
    if (distance < 0.0f)
        distance = 0.0f;
    return clamp01(1.0f / (1.0f + distance));
}

void lcd_draw_rectangle(int x, int y, int w, int h, uint32_t color, int line_width)
{
    for (int i = 0; i < line_width; i++)
    {
        for (int j = 0; j < w; j++)
        {
            if (x + j >= 0 && x + j < 1024 && y + i >= 0 && y + i < 600)
            {
                lcd_ptr[1024 * (y + i) + (x + j)] = color;
            }
        }
    }
    for (int i = 0; i < line_width; i++)
    {
        for (int j = 0; j < w; j++)
        {
            if (x + j >= 0 && x + j < 1024 && y + h - i >= 0 && y + h - i < 600)
            {
                lcd_ptr[1024 * (y + h - i) + (x + j)] = color;
            }
        }
    }
    for (int i = 0; i < line_width; i++)
    {
        for (int j = 0; j < h; j++)
        {
            if (x + i >= 0 && x + i < 1024 && y + j >= 0 && y + j < 600)
            {
                lcd_ptr[1024 * (y + j) + (x + i)] = color;
            }
        }
    }
    for (int i = 0; i < line_width; i++)
    {
        for (int j = 0; j < h; j++)
        {
            if (x + w - i >= 0 && x + w - i < 1024 && y + j >= 0 && y + j < 600)
            {
                lcd_ptr[1024 * (y + j) + (x + w - i)] = color;
            }
        }
    }
}

void lcd_force_clear_screen(void)
{
    memset(lcd_ptr, 0, 1024 * 600 * 4);
    DRMshowUp(drm_fd, &drm);
    memset(lcd_ptr, 0, 1024 * 600 * 4);
    DRMshowUp(drm_fd, &drm);
}

// ===================== 人脸裁剪函数 =====================
int crop_face_from_image(rockx_image_t *src_img, rockx_rect_t *face_box, rockx_image_t *dst_img)
{
    int left = face_box->left;
    int top = face_box->top;
    int right = face_box->right;
    int bottom = face_box->bottom;

    int expand_w = (right - left) / 10;
    int expand_h = (bottom - top) / 10;
    left = (left - expand_w) > 0 ? (left - expand_w) : 0;
    top = (top - expand_h) > 0 ? (top - expand_h) : 0;
    right = (right + expand_w) < src_img->width ? (right + expand_w) : src_img->width;
    bottom = (bottom + expand_h) < src_img->height ? (bottom + expand_h) : src_img->height;

    int crop_w = right - left;
    int crop_h = bottom - top;
    if (crop_w <= 0 || crop_h <= 0)
        return -1;

    dst_img->width = crop_w;
    dst_img->height = crop_h;
    dst_img->pixel_format = src_img->pixel_format;
    dst_img->data = (unsigned char *)calloc(1, crop_w * crop_h * 3);
    if (dst_img->data == NULL)
        return -1;

    unsigned char *src_ptr = src_img->data;
    unsigned char *dst_ptr = dst_img->data;
    int bytes_per_pixel = 3;
    for (int y = top; y < bottom; y++)
    {
        for (int x = left; x < right; x++)
        {
            int src_idx = (y * src_img->width + x) * bytes_per_pixel;
            int dst_idx = ((y - top) * crop_w + (x - left)) * bytes_per_pixel;
            memcpy(dst_ptr + dst_idx, src_ptr + src_idx, bytes_per_pixel);
        }
    }
    return 0;
}

// ===================== 统一特征提取函数 =====================
int extract_face_feature_from_image(rockx_image_t *src_image, rockx_face_feature_t *out_feature)
{
    memset(out_feature, 0, sizeof(rockx_face_feature_t));

    rockx_object_array_t face_array = {0};
    rockx_ret_t ret = rockx_face_detect(face_det_handle, src_image, &face_array, NULL);
    if (ret != ROCKX_RET_SUCCESS)
    {
        printf("特征提取：人脸检测失败\n");
        return -1;
    }

    rockx_object_t *valid_face = get_valid_max_face(&face_array);
    if (valid_face == NULL)
    {
        printf("特征提取：无有效人脸\n");
        return -1;
    }

    rockx_image_t aligned_face;
    memset(&aligned_face, 0, sizeof(rockx_image_t));
    aligned_face.width = FACE_ALIGN_SIZE;
    aligned_face.height = FACE_ALIGN_SIZE;
    aligned_face.pixel_format = ROCKX_PIXEL_FORMAT_RGB888;
    aligned_face.data = (unsigned char *)calloc(1, FACE_ALIGN_SIZE * FACE_ALIGN_SIZE * 3);
    if (aligned_face.data == NULL)
    {
        printf("特征提取：内存分配失败\n");
        return -1;
    }

    ret = rockx_face_align(face_5landmarks_handle, src_image, &valid_face->box, NULL, &aligned_face);
    if (ret != ROCKX_RET_SUCCESS)
    {
        printf("特征提取：人脸对齐失败\n");
        free(aligned_face.data);
        return -1;
    }

    ret = rockx_face_recognize(face_recognize_handle, &aligned_face, out_feature);
    if (ret != ROCKX_RET_SUCCESS)
    {
        printf("特征提取：特征提取失败\n");
        free(aligned_face.data);
        return -1;
    }

    free(aligned_face.data);
    printf("特征提取成功\n");
    return 0;
}

// ===================== 人脸比对函数（保留用于打卡） =====================
int extract_face_feature_from_box(rockx_image_t *src_image, rockx_rect_t *face_box, rockx_face_feature_t *out_feature)
{
    if (src_image == NULL || face_box == NULL || out_feature == NULL)
        return -1;

    memset(out_feature, 0, sizeof(rockx_face_feature_t));

    rockx_image_t aligned_face;
    memset(&aligned_face, 0, sizeof(rockx_image_t));
    aligned_face.width = FACE_ALIGN_SIZE;
    aligned_face.height = FACE_ALIGN_SIZE;
    aligned_face.pixel_format = ROCKX_PIXEL_FORMAT_RGB888;
    aligned_face.data = (unsigned char *)calloc(1, FACE_ALIGN_SIZE * FACE_ALIGN_SIZE * 3);
    if (aligned_face.data == NULL)
        return -1;

    rockx_ret_t ret = rockx_face_align(face_5landmarks_handle, src_image, face_box, NULL, &aligned_face);
    if (ret != ROCKX_RET_SUCCESS)
    {
        free(aligned_face.data);
        return -1;
    }

    ret = rockx_face_recognize(face_recognize_handle, &aligned_face, out_feature);
    free(aligned_face.data);
    if (ret != ROCKX_RET_SUCCESS)
        return -1;

    return 0;
}

int compare_face_with_database(rockx_face_feature_t *target_feature, char **matched_name, float *max_similarity)
{
    *max_similarity = 0.0f;
    *matched_name = NULL;
    float second_similarity = 0.0f;

    if (target_feature == NULL || target_feature->len <= 0)
    {
        return -1;
    }

    if (people == 0)
    {
        printf("人脸库为空\n");
        return -1;
    }

    printf("开始比对，库中人数: %d\n", people);
    for (int i = 0; i < people; i++)
    {
        if (face_features[i].len <= 0)
            continue;
        float raw_distance = 0.0f;
        float similarity = 0.0f;
        rockx_ret_t ret = rockx_face_feature_similarity(target_feature, &face_features[i], &raw_distance);

        if (ret != ROCKX_RET_SUCCESS)
        {
            printf("与用户%d比对失败\n", i + 1);
            continue;
        }

        similarity = distance_to_similarity(raw_distance);
        printf("  与%s比对：相似度 = %.4f\n", face_user_name[i], similarity);

        if (similarity > *max_similarity)
        {
            second_similarity = *max_similarity;
            *max_similarity = similarity;
            *matched_name = face_user_name[i];
        }
        else if (similarity > second_similarity)
        {
            second_similarity = similarity;
        }
    }

    float similarity_gap = *max_similarity - second_similarity;
    if (*max_similarity >= FACE_SIMILARITY_THRESHOLD && similarity_gap >= FACE_SIMILARITY_GAP && *matched_name != NULL)
    {
        printf("比对成功！用户：%s，相似度：%.4f\n", *matched_name, *max_similarity);
        return 0;
    }
    else
    {
        printf("比对失败，最大相似度：%.4f\n", *max_similarity);
        return -1;
    }
}

// ===================== JPEG解码相关 =====================
struct my_error_mgr
{
    struct jpeg_error_mgr pub;
    jmp_buf setjmp_buffer;
};
typedef struct my_error_mgr *my_error_ptr;
METHODDEF(void)
my_error_exit(j_common_ptr cinfo)
{
    my_error_ptr myerr = (my_error_ptr)cinfo->err;
    (*cinfo->err->output_message)(cinfo);
    longjmp(myerr->setjmp_buffer, 1);
}

int jpg_to_rgb(unsigned char *jpg_buffer, size_t jpg_size, struct image_info *minfo, int zoom_flag)
{
    struct jpeg_decompress_struct cinfo;
    struct my_error_mgr jerr;
    cinfo.err = jpeg_std_error(&jerr.pub);
    jerr.pub.error_exit = my_error_exit;
    if (setjmp(jerr.setjmp_buffer))
    {
        jpeg_destroy_decompress(&cinfo);
        return -1;
    }
    jpeg_create_decompress(&cinfo);
    jpeg_mem_src(&cinfo, jpg_buffer, jpg_size);
    if (jpeg_read_header(&cinfo, TRUE) != 1)
    {
        fprintf(stderr, "JPEG header read failed\n");
        return -1;
    }
    cinfo.scale_num = 1;
    cinfo.scale_denom = zoom_flag;
    jpeg_start_decompress(&cinfo);
    minfo->width = cinfo.output_width;
    minfo->height = cinfo.output_height;
    int row_stride = cinfo.output_width * cinfo.output_components;
    minfo->rgb = calloc(1, cinfo.output_height * row_stride);
    if (!minfo->rgb)
    {
        fprintf(stderr, "Memory allocation failed\n");
        jpeg_destroy_decompress(&cinfo);
        return -1;
    }
    while (cinfo.output_scanline < cinfo.output_height)
    {
        unsigned char *buffer_array[1];
        buffer_array[0] = (unsigned char *)(minfo->rgb + (cinfo.output_scanline) * row_stride);
        jpeg_read_scanlines(&cinfo, buffer_array, 1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return 0;
}

void load_jpeg_from_file(const char *jpgfile, struct image_info *minfo, int zoom_flag)
{
    struct stat file_info;
    if (stat(jpgfile, &file_info) == -1)
        return;
    int fd = open(jpgfile, O_RDONLY);
    if (fd == -1)
        return;
    unsigned char *jpg_buffer = (unsigned char *)calloc(1, file_info.st_size);
    if (!jpg_buffer)
    {
        close(fd);
        return;
    }
    ssize_t nread = read(fd, jpg_buffer, file_info.st_size);
    close(fd);
    if (nread <= 0)
    {
        free(jpg_buffer);
        return;
    }
    jpg_to_rgb(jpg_buffer, nread, minfo, zoom_flag);
    free(jpg_buffer);
}

int lcd_draw_jpeg(int x, int y, const char *pathname, unsigned char *jpeg_buffer, long unsigned int jpeg_size, struct drmHandle *drm, int zoom_flag)
{
    if ((current_page != PAGE_CLOCK && current_page != PAGE_ADMIN_FACE_REG) || camera_running != 1)
        return -1;
    struct image_info *minfo = (struct image_info *)calloc(1, sizeof(struct image_info));
    if (!minfo)
        return -1;
    if (jpeg_buffer && jpeg_size > 0)
    {
        if (jpg_to_rgb(jpeg_buffer, jpeg_size, minfo, zoom_flag) != 0)
        {
            free(minfo);
            return -1;
        }
    }
    else if (pathname)
    {
        load_jpeg_from_file(pathname, minfo, zoom_flag);
        if (!minfo->rgb)
        {
            free(minfo);
            return -1;
        }
    }
    else
    {
        free(minfo);
        return -1;
    }
    int i, j;
    for (i = 0; i < minfo->height && (y + i) < drm->height; i++)
    {
        for (j = 0; j < minfo->width && (x + j) < drm->width; j++)
        {
            uint32_t lcd_offset = 4 * (x + j) + drm->width * 4 * (y + i);
            uint32_t rgb_offset = 3 * j + minfo->width * 3 * i;
            memcpy(drm->vaddr + lcd_offset + 0, minfo->rgb + rgb_offset + 2, 1);
            memcpy(drm->vaddr + lcd_offset + 1, minfo->rgb + rgb_offset + 1, 1);
            memcpy(drm->vaddr + lcd_offset + 2, minfo->rgb + rgb_offset + 0, 1);
        }
    }
    free(minfo->rgb);
    free(minfo);
    DRMshowUp(drm_fd, drm);
    return 0;
}

int lcd_draw_bmp(const char *pathname, int x, int y, int w, int h)
{
    int bmp_fd = open(pathname, O_RDONLY);
    if (bmp_fd < 0)
    {
        fprintf(stderr, "警告：找不到图片 %s\n", pathname);
        return -1;
    }
    char header[54] = {0};
    char rgb_buf[w * h * 3];
    read(bmp_fd, header, 54);
    read(bmp_fd, rgb_buf, w * h * 3);
    int i, j, r, g, b, color;
    for (j = 0; j < h; j++)
    {
        for (i = 0; i < w; i++)
        {
            b = rgb_buf[(w * j + i) * 3 + 0];
            g = rgb_buf[(w * j + i) * 3 + 1];
            r = rgb_buf[(w * j + i) * 3 + 2];
            color = b | g << 8 | r << 16 | 0 << 24;
            lcd_ptr[1024 * (h - 1 - j + y) + i + x] = color;
        }
    }
    close(bmp_fd);
    DRMshowUp(drm_fd, &drm);
    return 0;
}

// 数字字体绘制
const unsigned char digit_font[12][16] = {
    {0x00, 0x00, 0x3C, 0x66, 0x66, 0x6E, 0x76, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x18, 0x38, 0x78, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x3C, 0x66, 0x66, 0x06, 0x0C, 0x18, 0x30, 0x60, 0x66, 0x7E, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x3C, 0x66, 0x66, 0x06, 0x1C, 0x06, 0x06, 0x66, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x0C, 0x1C, 0x3C, 0x6C, 0xCC, 0xFE, 0x0C, 0x0C, 0x0C, 0x1E, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x7E, 0x60, 0x60, 0x7C, 0x66, 0x06, 0x06, 0x66, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x1C, 0x30, 0x60, 0x60, 0x7C, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x7E, 0x66, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x3C, 0x66, 0x66, 0x66, 0x3C, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x3C, 0x66, 0x66, 0x66, 0x66, 0x3E, 0x06, 0x06, 0x0C, 0x38, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x00, 0x66, 0x3C, 0xFF, 0x3C, 0x66, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x18, 0x18, 0x7E, 0x18, 0x18, 0x7E, 0x18, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};
void lcd_draw_digit(int x, int y, char c, uint32_t color)
{
    int num = -1;
    if (c >= '0' && c <= '9')
        num = c - '0';
    else if (c == '*')
        num = 10;
    else if (c == '#')
        num = 11;
    else
        return;
    int i, j;
    for (i = 0; i < 16; i++)
    {
        unsigned char line = digit_font[num][i];
        for (j = 0; j < 8; j++)
        {
            if (line & (0x80 >> j))
            {
                for (int m = 0; m < 3; m++)
                    for (int n = 0; n < 3; n++)
                        lcd_ptr[1024 * (y + i * 3 + m) + (x + j * 3 + n)] = color;
            }
        }
    }
}
void lcd_draw_number(int x, int y, const char *num, uint32_t color)
{
    int i = 0;
    while (num[i] != '\0' && i < 20)
    {
        lcd_draw_digit(x + i * 30, y, num[i], color);
        i++;
    }
}

void save_current_frame_to_file(rockx_image_t *image, const char *path)
{
    rockx_image_write(path, image);
}

// ===================== 有效人脸获取 =====================
rockx_object_t *get_valid_max_face(rockx_object_array_t *face_array)
{
    if (face_array->count == 0)
        return NULL;
    int max_idx = -1;
    int max_area = 0;
    for (int i = 0; i < face_array->count; i++)
    {
        rockx_object_t *face = &face_array->object[i];
        if (face->score < FACE_CONFIDENCE_THRESHOLD)
            continue;
        int w = face->box.right - face->box.left;
        int h = face->box.bottom - face->box.top;
        if (w < FACE_MIN_SIZE || h < FACE_MIN_SIZE)
            continue;
        int area = w * h;
        if (area > max_area)
        {
            max_area = area;
            max_idx = i;
        }
    }
    if (max_idx == -1)
        return NULL;
    return &face_array->object[max_idx];
}

// ===================== 【已修改】人脸注册函数：去掉相似度查重，允许重复录入 =====================
void register_face(rockx_image_t *full_image, rockx_rect_t *face_box)
{
    if (people >= MAX_FACE_USER)
    {
        lcd_draw_bmp(ERROR_IMG, ERROR_X, ERROR_Y, ERROR_W, ERROR_H);
        DRMshowUp(drm_fd, &drm);
        sleep(2);
        show_current_page();
        return;
    }

    rockx_image_t cropped_face;
    memset(&cropped_face, 0, sizeof(rockx_image_t));
    if (crop_face_from_image(full_image, face_box, &cropped_face) != 0)
    {
        lcd_draw_bmp(ERROR_IMG, ERROR_X, ERROR_Y, ERROR_W, ERROR_H);
        DRMshowUp(drm_fd, &drm);
        sleep(2);
        show_current_page();
        return;
    }

    rockx_face_feature_t new_feature;
    if (extract_face_feature_from_box(full_image, face_box, &new_feature) != 0)
    {
        if (cropped_face.data)
            free(cropped_face.data);
        lcd_draw_bmp(ERROR_IMG, ERROR_X, ERROR_Y, ERROR_W, ERROR_H);
        DRMshowUp(drm_fd, &drm);
        sleep(2);
        show_current_page();
        return;
    }

    // 【已删除】相似度查重逻辑，直接录入
    memcpy(&face_features[people], &new_feature, sizeof(rockx_face_feature_t));
    sprintf(face_user_name[people], "用户%d", people + 1);
    people = people + 1;

    char path[200] = {0};
    sprintf(path, "%s_face.jpg", face_user_name[people - 1]);
    save_current_frame_to_file(&cropped_face, path);
    strcpy(last_captured_face, path);
    show_captured_face = 1;

    if (cropped_face.data)
        free(cropped_face.data);

    printf("注册成功：%s，当前总人数：%d\n", face_user_name[people - 1], people);
    lcd_draw_bmp("lrcg.bmp", SUCCESS_X, SUCCESS_Y, SUCCESS_W, SUCCESS_H);
    DRMshowUp(drm_fd, &drm);
    sleep(2);
    show_current_page();
}

// ===================== 上班打卡函数（保留相似度比对） =====================
void punch_in(rockx_face_feature_t *feature, rockx_image_t *cropped_face)
{
    char path[200] = {0};
    sprintf(path, "clock_in_%d.jpg", clock_in_num);

    save_current_frame_to_file(cropped_face, path);
    strcpy(last_captured_face, path);
    show_captured_face = 1;
    show_current_page();

    char *matched_name = NULL;
    float max_similarity = 0.0f;
    if (compare_face_with_database(feature, &matched_name, &max_similarity) == 0 && matched_name != NULL && max_similarity >= FACE_SIMILARITY_THRESHOLD)
    {
        char msg[1024] = {0};
        sprintf(msg, "PunchInface/%s", matched_name);
        if (send_msg("192.168.1.159", 6666, msg) != -1)
        {
            lcd_draw_bmp(SUCCESS_IMG, SUCCESS_X, SUCCESS_Y, SUCCESS_W, SUCCESS_H);
            clock_in_num++;
            printf("上班打卡成功：%s，相似度：%.4f\n", matched_name, max_similarity);
        }
        else
        {
            lcd_draw_bmp(FAIL_IMG, FAIL_X, FAIL_Y, FAIL_W, FAIL_H);
        }
    }
    else
    {
        lcd_draw_bmp(FAIL_IMG, FAIL_X, FAIL_Y, FAIL_W, FAIL_H);
    }

    DRMshowUp(drm_fd, &drm);
    sleep(2);
    show_current_page();
}

// ===================== 下班打卡函数（保留相似度比对） =====================
void punch_out(rockx_face_feature_t *feature, rockx_image_t *cropped_face)
{
    char path[200] = {0};
    sprintf(path, "clock_out_%d.jpg", clock_out_num);

    save_current_frame_to_file(cropped_face, path);
    strcpy(last_captured_face, path);
    show_captured_face = 1;
    show_current_page();

    char *matched_name = NULL;
    float max_similarity = 0.0f;
    if (compare_face_with_database(feature, &matched_name, &max_similarity) == 0 && matched_name != NULL && max_similarity >= FACE_SIMILARITY_THRESHOLD)
    {
        char msg[1024] = {0};
        sprintf(msg, "PunchOutface/%s", matched_name);
        if (send_msg("192.168.1.159", 6666, msg) != -1)
        {
            lcd_draw_bmp(SUCCESS_IMG, SUCCESS_X, SUCCESS_Y, SUCCESS_W, SUCCESS_H);
            clock_out_num++;
            printf("下班打卡成功：%s，相似度：%.4f\n", matched_name, max_similarity);
        }
        else
        {
            lcd_draw_bmp(FAIL_IMG, FAIL_X, FAIL_Y, FAIL_W, FAIL_H);
        }
    }
    else
    {
        lcd_draw_bmp(FAIL_IMG, FAIL_X, FAIL_Y, FAIL_W, FAIL_H);
    }

    DRMshowUp(drm_fd, &drm);
    sleep(2);
    show_current_page();
}

// ===================== 摄像头线程 =====================
void *clock_camera_thread(void *arg)
{
    pthread_detach(pthread_self());
    camera_running = 1;

    unsigned char *rgb_buffer = (unsigned char *)malloc(CAMERA_WIDTH * CAMERA_HEIGHT * 3);
    rockx_image_t input_image;
    input_image.width = CAMERA_WIDTH;
    input_image.height = CAMERA_HEIGHT;
    input_image.pixel_format = ROCKX_PIXEL_FORMAT_RGB888;
    input_image.data = rgb_buffer;

    while (1)
    {
        if (camera_running != 1 || (current_page != PAGE_CLOCK && current_page != PAGE_ADMIN_FACE_REG))
            break;

        pthread_mutex_lock(&cam_mutex);
        if (camera_running != 1 || (current_page != PAGE_CLOCK && current_page != PAGE_ADMIN_FACE_REG))
        {
            pthread_mutex_unlock(&cam_mutex);
            break;
        }

        camera_capture_get_frame(&jpeg_buf);
        yuyv_to_rgb888(jpeg_buf.start, rgb_buffer, CAMERA_WIDTH, CAMERA_HEIGHT, CAMERA_WIDTH, CAMERA_HEIGHT);
        yuyv2jpeg(jpeg_buf.start, jpeg_buf.length, 99);
        lcd_draw_jpeg(CAM_PREVIEW_X, CAM_PREVIEW_Y, NULL, jpeg_buf.start, jpeg_buf.length, &drm, CAM_PREVIEW_ZOOM);

        rockx_object_array_t face_array = {0};
        rockx_ret_t ret = rockx_face_detect(face_det_handle, &input_image, &face_array, NULL);
        rockx_object_t *valid_face = NULL;

        if (ret == ROCKX_RET_SUCCESS && face_array.count > 0)
        {
            valid_face = get_valid_max_face(&face_array);
            if (valid_face != NULL)
            {
                int box_x = CAM_PREVIEW_X + valid_face->box.left * CAM_PREVIEW_ZOOM;
                int box_y = CAM_PREVIEW_Y + valid_face->box.top * CAM_PREVIEW_ZOOM;
                int box_w = (valid_face->box.right - valid_face->box.left) * CAM_PREVIEW_ZOOM;
                int box_h = (valid_face->box.bottom - valid_face->box.top) * CAM_PREVIEW_ZOOM;
                lcd_draw_rectangle(box_x, box_y, box_w, box_h, 0x00FF0000, 3);
                DRMshowUp(drm_fd, &drm);
            }
        }

        if ((get_face == 1 || take_face == 1 || take_face == 2) && valid_face != NULL)
        {
            rockx_image_t cropped_face;
            memset(&cropped_face, 0, sizeof(rockx_image_t));
            if (crop_face_from_image(&input_image, &valid_face->box, &cropped_face) == 0)
            {
                rockx_face_feature_t current_feature;
                if (extract_face_feature_from_box(&input_image, &valid_face->box, &current_feature) == 0)
                {
                    if (get_face == 1)
                    {
                        register_face(&input_image, &valid_face->box);
                        get_face = 0;
                    }
                    else if (take_face == 1)
                    {
                        punch_in(&current_feature, &cropped_face);
                        take_face = 0;
                    }
                    else if (take_face == 2)
                    {
                        punch_out(&current_feature, &cropped_face);
                        take_face = 0;
                    }
                }
            }
            if (cropped_face.data)
                free(cropped_face.data);
            get_face = 0;
            take_face = 0;
        }

        pthread_mutex_unlock(&cam_mutex);
        usleep(30000);
    }

    free(rgb_buffer);
    pthread_mutex_lock(&cam_mutex);
    camera_capture_stop_capturing();
    camera_capture_uninit(&jpeg_buf);
    camera_capture_close();
    pthread_mutex_unlock(&cam_mutex);
    camera_running = 0;
    pthread_exit(NULL);
}

// ===================== 页面绘制 =====================
void show_current_page(void)
{
    memset(lcd_ptr, 0, 1024 * 600 * 4);
    switch (current_page)
    {
    case PAGE_HOME:
        lcd_draw_bmp(PAGE1_BG_IMG, PAGE1_BG_X, PAGE1_BG_Y, PAGE1_BG_W, PAGE1_BG_H);
        lcd_draw_bmp(BTN_ENTER_IMG, BTN_ENTER_X, BTN_ENTER_Y, BTN_ENTER_W, BTN_ENTER_H);
        lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
        break;
    case PAGE_SELECT:
        lcd_draw_bmp(PAGE2_BG_IMG, PAGE2_BG_X, PAGE2_BG_Y, PAGE2_BG_W, PAGE2_BG_H);
        lcd_draw_bmp(BTN_BACK1_IMG, BTN_BACK1_X, BTN_BACK1_Y, BTN_BACK1_W, BTN_BACK1_H);
        lcd_draw_bmp(BTN_USER_IMG, BTN_USER_X, BTN_USER_Y, BTN_USER_W, BTN_USER_H);
        lcd_draw_bmp(BTN_ADMIN_IMG, BTN_ADMIN_X, BTN_ADMIN_Y, BTN_ADMIN_W, BTN_ADMIN_H);
        lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
        break;
    case PAGE_USER_LOGIN:
        lcd_draw_bmp(PAGE3_BG_IMG, PAGE3_BG_X, PAGE3_BG_Y, PAGE3_BG_W, PAGE3_BG_H);
        lcd_draw_bmp(BTN_BACK2_IMG, BTN_BACK2_X, BTN_BACK2_Y, BTN_BACK2_W, BTN_BACK2_H);
        lcd_draw_bmp(BTN_SUBMIT_IMG, BTN_SUBMIT_X, BTN_SUBMIT_Y, BTN_SUBMIT_W, BTN_SUBMIT_H);
        lcd_draw_number(USER_ID_X + 5, USER_ID_Y + 15, user_id, 0x000000);
        lcd_draw_number(USER_PWD_X + 5, USER_PWD_Y + 15, user_pwd, 0x000000);
        lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
        break;
    case PAGE_ADMIN:
        lcd_draw_bmp(PAGE4_BG_IMG, PAGE4_BG_X, PAGE4_BG_Y, PAGE4_BG_W, PAGE4_BG_H);
        lcd_draw_bmp(BTN_BACK3_IMG, BTN_BACK3_X, BTN_BACK3_Y, BTN_BACK3_W, BTN_BACK3_H);
        lcd_draw_bmp(BTN_EXIT_IMG, BTN_EXIT_X, BTN_EXIT_Y, BTN_EXIT_W, BTN_EXIT_H);
        lcd_draw_bmp(BTN_REG_IMG, BTN_REG_X, BTN_REG_Y, BTN_REG_W, BTN_REG_H);
        lcd_draw_bmp(BTN_QUERY_IMG, BTN_QUERY_X, BTN_QUERY_Y, BTN_QUERY_W, BTN_QUERY_H);
        lcd_draw_number(ADMIN_ID_X + 5, ADMIN_ID_Y + 10, admin_id, 0x000000);
        lcd_draw_number(ADMIN_PWD_X + 5, ADMIN_PWD_Y + 10, admin_pwd, 0x000000);
        break;
    case PAGE_CLOCK:
        lcd_draw_bmp(PAGE5_BG_IMG, PAGE5_BG_X, PAGE5_BG_Y, PAGE5_BG_W, PAGE5_BG_H);
        lcd_draw_bmp(BTN_BACK4_IMG, BTN_BACK4_X, BTN_BACK4_Y, BTN_BACK4_W, BTN_BACK4_H);
        lcd_draw_bmp(BTN_IN_IMG, BTN_IN_X, BTN_IN_Y, BTN_IN_W, BTN_IN_H);
        lcd_draw_bmp(BTN_OUT_IMG, BTN_OUT_X, BTN_OUT_Y, BTN_OUT_W, BTN_OUT_H);
        if (show_captured_face && strlen(last_captured_face) > 0)
        {
            lcd_draw_jpeg(SNAP_SHOW_X, SNAP_SHOW_Y, last_captured_face, NULL, 0, &drm, SNAP_SHOW_ZOOM);
        }
        break;
    case PAGE_ADMIN_FACE_REG:
        lcd_draw_bmp(PAGE5_BG_IMG, PAGE5_BG_X, PAGE5_BG_Y, PAGE5_BG_W, PAGE5_BG_H);
        lcd_draw_bmp(BTN_BACK4_IMG, BTN_BACK4_X, BTN_BACK4_Y, BTN_BACK4_W, BTN_BACK4_H);
        lcd_draw_bmp(BTN_REG_FACE_IMG, BTN_REG_FACE_X, BTN_REG_FACE_Y, BTN_REG_FACE_W, BTN_REG_FACE_H);
        if (show_captured_face && strlen(last_captured_face) > 0)
        {
            lcd_draw_jpeg(SNAP_SHOW_X, SNAP_SHOW_Y, last_captured_face, NULL, 0, &drm, SNAP_SHOW_ZOOM);
        }
        break;
    case PAGE_KEYBOARD:
        lcd_draw_bmp(PAGE6_BG_IMG, PAGE6_BG_X, PAGE6_BG_Y, PAGE6_BG_W, PAGE6_BG_H);
        lcd_draw_number(INPUT_DISPLAY_X + 10, INPUT_DISPLAY_Y + 10, input_buf, 0x000000);
        break;
    default:
        break;
    }
    DRMshowUp(drm_fd, &drm);
}

// ===================== 触摸数据获取 =====================
TouchPoint get_touch_data(int fd)
{
    struct input_event ev;
    static TouchPoint point = {0};
    point.valid = false;
    while (read(fd, &ev, sizeof(ev)) == sizeof(ev))
    {
        switch (ev.type)
        {
        case EV_ABS:
            if (ev.code == ABS_X)
                point.x = ev.value;
            if (ev.code == ABS_Y)
                point.y = ev.value;
            if (ev.code == ABS_PRESSURE)
                point.pressure = ev.value;
            break;
        case EV_KEY:
            if (ev.code == BTN_TOUCH && ev.value == 0)
            {
                point.valid = true;
                return point;
            }
            break;
        }
    }
    return (TouchPoint){0};
}

// ===================== 触摸按键检测 =====================
void check_touch_buttons(TouchPoint p)
{
    if (current_page != PAGE_CLOCK && current_page != PAGE_KEYBOARD && current_page != PAGE_ADMIN_FACE_REG &&
        p.x >= BTN_EXIT_X && p.x <= BTN_EXIT_X + BTN_EXIT_W &&
        p.y >= BTN_EXIT_Y && p.y <= BTN_EXIT_Y + BTN_EXIT_H)
    {
        dev_uninit();
        exit(0);
    }
    switch (current_page)
    {
    case PAGE_HOME:
        if (p.x >= BTN_ENTER_X && p.x <= BTN_ENTER_X + BTN_ENTER_W &&
            p.y >= BTN_ENTER_Y && p.y <= BTN_ENTER_Y + BTN_ENTER_H)
        {
            current_page = PAGE_SELECT;
            show_current_page();
        }
        break;
    case PAGE_SELECT:
        if (p.x >= BTN_BACK1_X && p.x <= BTN_BACK1_X + BTN_BACK1_W &&
            p.y >= BTN_BACK1_Y && p.y <= BTN_BACK1_Y + BTN_BACK1_H)
        {
            current_page = PAGE_HOME;
            show_current_page();
        }
        else if (p.x >= BTN_USER_X && p.x <= BTN_USER_X + BTN_USER_W &&
                 p.y >= BTN_USER_Y && p.y <= BTN_USER_Y + BTN_USER_H)
        {
            current_page = PAGE_USER_LOGIN;
            show_current_page();
        }
        else if (p.x >= BTN_ADMIN_X && p.x <= BTN_ADMIN_X + BTN_ADMIN_W &&
                 p.y >= BTN_ADMIN_Y && p.y <= BTN_ADMIN_Y + BTN_ADMIN_H)
        {
            current_page = PAGE_ADMIN;
            show_current_page();
        }
        break;
    case PAGE_USER_LOGIN:
        if (p.x >= BTN_BACK2_X && p.x <= BTN_BACK2_X + BTN_BACK2_W &&
            p.y >= BTN_BACK2_Y && p.y <= BTN_BACK2_Y + BTN_BACK2_H)
        {
            current_page = PAGE_SELECT;
            show_current_page();
        }
        else if (p.x >= USER_ID_X && p.x <= USER_ID_X + USER_ID_W &&
                 p.y >= USER_ID_Y && p.y <= USER_ID_Y + USER_ID_H)
        {
            current_input = INPUT_USER_ID;
            memset(input_buf, 0, sizeof(input_buf));
            input_len = 0;
            current_page = PAGE_KEYBOARD;
            show_current_page();
        }
        else if (p.x >= USER_PWD_X && p.x <= USER_PWD_X + USER_PWD_W &&
                 p.y >= USER_PWD_Y && p.y <= USER_PWD_Y + USER_PWD_H)
        {
            current_input = INPUT_USER_PWD;
            memset(input_buf, 0, sizeof(input_buf));
            input_len = 0;
            current_page = PAGE_KEYBOARD;
            show_current_page();
        }
        else if (p.x >= BTN_SUBMIT_X && p.x <= BTN_SUBMIT_X + BTN_SUBMIT_W &&
                 p.y >= BTN_SUBMIT_Y && p.y <= BTN_SUBMIT_Y + BTN_SUBMIT_H)
        {
            if (strcmp(user_id, DEFAULT_USER_ID) == 0 && strcmp(user_pwd, DEFAULT_USER_PWD) == 0)
            {
                current_page = PAGE_CLOCK;
                show_current_page();
                if (0 != camera_capture_open(DEV_CAMERA))
                    printf("摄像头打开失败\n");
                else
                {
                    camera_capture_init(&jpeg_buf);
                    camera_capture_start_capturing();
                    pthread_create(&camera_tid, NULL, clock_camera_thread, NULL);
                }
            }
            else
            {
                lcd_draw_bmp(ERROR_IMG, ERROR_X, ERROR_Y, ERROR_W, ERROR_H);
                DRMshowUp(drm_fd, &drm);
                sleep(2);
                show_current_page();
            }
        }
        break;
    case PAGE_ADMIN:
        if (p.x >= BTN_BACK3_X && p.x <= BTN_BACK3_X + BTN_BACK3_W &&
            p.y >= BTN_BACK3_Y && p.y <= BTN_BACK3_Y + BTN_BACK3_H)
        {
            current_page = PAGE_SELECT;
            show_current_page();
        }
        else if (p.x >= ADMIN_ID_X && p.x <= ADMIN_ID_X + ADMIN_ID_W &&
                 p.y >= ADMIN_ID_Y && p.y <= ADMIN_ID_Y + ADMIN_ID_H)
        {
            current_input = INPUT_ADMIN_ID;
            memset(input_buf, 0, sizeof(input_buf));
            input_len = 0;
            current_page = PAGE_KEYBOARD;
            show_current_page();
        }
        else if (p.x >= ADMIN_PWD_X && p.x <= ADMIN_PWD_X + ADMIN_PWD_W &&
                 p.y >= ADMIN_PWD_Y && p.y <= ADMIN_PWD_Y + ADMIN_PWD_H)
        {
            current_input = INPUT_ADMIN_PWD;
            memset(input_buf, 0, sizeof(input_buf));
            input_len = 0;
            current_page = PAGE_KEYBOARD;
            show_current_page();
        }
        else if (p.x >= BTN_REG_X && p.x <= BTN_REG_X + BTN_REG_W &&
                 p.y >= BTN_REG_Y && p.y <= BTN_REG_Y + BTN_REG_H)
        {
            if (strcmp(admin_id, DEFAULT_ADMIN_ID) == 0 && strcmp(admin_pwd, DEFAULT_ADMIN_PWD) == 0)
            {
                current_page = PAGE_ADMIN_FACE_REG;
                show_current_page();
                if (0 != camera_capture_open(DEV_CAMERA))
                    printf("摄像头打开失败\n");
                else
                {
                    camera_capture_init(&jpeg_buf);
                    camera_capture_start_capturing();
                    pthread_create(&camera_tid, NULL, clock_camera_thread, NULL);
                }
            }
            else
            {
                lcd_draw_bmp(ERROR_IMG, ERROR_X, ERROR_Y, ERROR_W, ERROR_H);
                DRMshowUp(drm_fd, &drm);
                sleep(2);
                show_current_page();
            }
        }
        break;
    case PAGE_CLOCK:
        if (p.x >= BTN_BACK4_X && p.x <= BTN_BACK4_X + BTN_BACK4_W &&
            p.y >= BTN_BACK4_Y && p.y <= BTN_BACK4_Y + BTN_BACK4_H)
        {
            camera_running = 0;
            pthread_mutex_lock(&cam_mutex);
            pthread_mutex_unlock(&cam_mutex);
            pthread_join(camera_tid, NULL);
            lcd_force_clear_screen();
            if (snap_buf.start)
            {
                free(snap_buf.start);
                snap_buf.start = NULL;
                snap_buf.length = 0;
            }
            show_captured_face = 0;
            current_page = PAGE_USER_LOGIN;
            show_current_page();
        }
        else if (p.x >= BTN_IN_X && p.x <= BTN_IN_X + BTN_IN_W &&
                 p.y >= BTN_IN_Y && p.y <= BTN_IN_Y + BTN_IN_H)
        {
            take_face = 1;
        }
        else if (p.x >= BTN_OUT_X && p.x <= BTN_OUT_X + BTN_OUT_W &&
                 p.y >= BTN_OUT_Y && p.y <= BTN_OUT_Y + BTN_OUT_H)
        {
            take_face = 2;
        }
        break;
    case PAGE_ADMIN_FACE_REG:
        if (p.x >= BTN_BACK4_X && p.x <= BTN_BACK4_X + BTN_BACK4_W &&
            p.y >= BTN_BACK4_Y && p.y <= BTN_BACK4_Y + BTN_BACK4_H)
        {
            camera_running = 0;
            pthread_mutex_lock(&cam_mutex);
            pthread_mutex_unlock(&cam_mutex);
            pthread_join(camera_tid, NULL);
            lcd_force_clear_screen();
            if (snap_buf.start)
            {
                free(snap_buf.start);
                snap_buf.start = NULL;
                snap_buf.length = 0;
            }
            show_captured_face = 0;
            current_page = PAGE_ADMIN;
            show_current_page();
        }
        else if (p.x >= BTN_REG_FACE_X && p.x <= BTN_REG_FACE_X + BTN_REG_FACE_W &&
                 p.y >= BTN_REG_FACE_Y && p.y <= BTN_REG_FACE_Y + BTN_REG_FACE_H)
        {
            get_face = 1;
        }
        break;
    case PAGE_KEYBOARD:
        if (p.x >= BTN_1_X && p.x <= BTN_1_X + BTN_1_W && p.y >= BTN_1_Y && p.y <= BTN_1_Y + BTN_1_H && input_len < 19)
        {
            input_buf[input_len++] = '1';
            show_current_page();
        }
        else if (p.x >= BTN_2_X && p.x <= BTN_2_X + BTN_2_W && p.y >= BTN_2_Y && p.y <= BTN_2_Y + BTN_2_H && input_len < 19)
        {
            input_buf[input_len++] = '2';
            show_current_page();
        }
        else if (p.x >= BTN_3_X && p.x <= BTN_3_X + BTN_3_W && p.y >= BTN_3_Y && p.y <= BTN_3_Y + BTN_3_H && input_len < 19)
        {
            input_buf[input_len++] = '3';
            show_current_page();
        }
        else if (p.x >= BTN_4_X && p.x <= BTN_4_W && p.y >= BTN_4_Y && p.y <= BTN_4_Y + BTN_4_H && input_len < 19)
        {
            input_buf[input_len++] = '4';
            show_current_page();
        }
        else if (p.x >= BTN_5_X && p.x <= BTN_5_X + BTN_5_W && p.y >= BTN_5_Y && p.y <= BTN_5_Y + BTN_5_H && input_len < 19)
        {
            input_buf[input_len++] = '5';
            show_current_page();
        }
        else if (p.x >= BTN_6_X && p.x <= BTN_6_X + BTN_6_W && p.y >= BTN_6_Y && p.y <= BTN_6_Y + BTN_6_H && input_len < 19)
        {
            input_buf[input_len++] = '6';
            show_current_page();
        }
        else if (p.x >= BTN_7_X && p.x <= BTN_7_X + BTN_7_W && p.y >= BTN_7_Y && p.y <= BTN_7_Y + BTN_7_H && input_len < 19)
        {
            input_buf[input_len++] = '7';
            show_current_page();
        }
        else if (p.x >= BTN_8_X && p.x <= BTN_8_X + BTN_8_W && p.y >= BTN_8_Y && p.y <= BTN_8_Y + BTN_8_H && input_len < 19)
        {
            input_buf[input_len++] = '8';
            show_current_page();
        }
        else if (p.x >= BTN_9_X && p.x <= BTN_9_X + BTN_9_W && p.y >= BTN_9_Y && p.y <= BTN_9_Y + BTN_9_H && input_len < 19)
        {
            input_buf[input_len++] = '9';
            show_current_page();
        }
        else if (p.x >= BTN_0_X && p.x <= BTN_0_X + BTN_0_W && p.y >= BTN_0_Y && p.y <= BTN_0_Y + BTN_0_H && input_len < 19)
        {
            input_buf[input_len++] = '0';
            show_current_page();
        }
        else if (p.x >= BTN_STAR_X && p.x <= BTN_STAR_X + BTN_STAR_W && p.y >= BTN_STAR_Y && p.y <= BTN_STAR_Y + BTN_STAR_H && input_len < 19)
        {
            input_buf[input_len++] = '*';
            show_current_page();
        }
        else if (p.x >= BTN_SHARP_X && p.x <= BTN_SHARP_X + BTN_SHARP_W && p.y >= BTN_SHARP_Y && p.y <= BTN_SHARP_Y + BTN_SHARP_H && input_len < 19)
        {
            input_buf[input_len++] = '#';
            show_current_page();
        }
        else if (p.x >= BTN_OK_X && p.x <= BTN_OK_X + BTN_OK_W && p.y >= BTN_OK_Y && p.y <= BTN_OK_Y + BTN_OK_H)
        {
            switch (current_input)
            {
            case INPUT_USER_ID:
                strcpy(user_id, input_buf);
                current_page = PAGE_USER_LOGIN;
                break;
            case INPUT_USER_PWD:
                strcpy(user_pwd, input_buf);
                current_page = PAGE_USER_LOGIN;
                break;
            case INPUT_ADMIN_ID:
                strcpy(admin_id, input_buf);
                current_page = PAGE_ADMIN;
                break;
            case INPUT_ADMIN_PWD:
                strcpy(admin_pwd, input_buf);
                current_page = PAGE_ADMIN;
                break;
            default:
                break;
            }
            show_current_page();
        }
        break;
    default:
        break;
    }
}

// ===================== 初始化函数 =====================
int init_face(void)
{
    rockx_ret_t ret;
    memset(face_features, 0, sizeof(face_features));
    memset(face_user_name, 0, sizeof(face_user_name));
    people = 0;

    ret = rockx_create(&face_det_handle, ROCKX_MODULE_FACE_DETECTION, NULL, 0);
    if (ret != ROCKX_RET_SUCCESS)
        return -1;
    ret = rockx_create(&face_5landmarks_handle, ROCKX_MODULE_FACE_LANDMARK_5, NULL, 0);
    if (ret != ROCKX_RET_SUCCESS)
        return -1;
    ret = rockx_create(&face_recognize_handle, ROCKX_MODULE_FACE_RECOGNIZE, NULL, 0);
    if (ret != ROCKX_RET_SUCCESS)
        return -1;
    printf("人脸识别模块初始化成功\n");
    return 0;
}

// ===================== 辅助函数 =====================
int send_msg(char *ip, short port, char *msg)
{
    int tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);
    int ret = connect(tcp_socket, (struct sockaddr *)&addr, sizeof(addr));
    if (ret < 0)
    {
        close(tcp_socket);
        return -1;
    }
    int size = write(tcp_socket, msg, strlen(msg));
    close(tcp_socket);
    return size;
}

int dev_init(void)
{
    drm_fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
    if (drm_fd < 0)
        return -1;
    DRMinit(drm_fd);
    DRMcreateFB(drm_fd, &drm);
    lcd_ptr = (uint32_t *)drm.vaddr;
    ts_fd = open("/dev/input/event2", O_RDONLY);
    if (ts_fd == -1)
        return -1;
    pthread_mutex_init(&cam_mutex, NULL);
    if (init_face() != 0)
        return -1;
    return 0;
}

void dev_uninit(void)
{
    camera_running = 0;
    usleep(200000);
    if (snap_buf.start)
    {
        free(snap_buf.start);
        snap_buf.start = NULL;
    }
    rockx_destroy(face_det_handle);
    rockx_destroy(face_5landmarks_handle);
    rockx_destroy(face_recognize_handle);
    pthread_mutex_destroy(&cam_mutex);
    close(ts_fd);
    DRMfreeResources(drm_fd, &drm);
    close(drm_fd);
}

int main(void)
{
    if (dev_init() < 0)
    {
        dev_uninit();
        return -1;
    }
    lcd_force_clear_screen();
    show_current_page();
    while (1)
    {
        TouchPoint point = get_touch_data(ts_fd);
        if (point.valid)
        {
            check_touch_buttons(point);
            usleep(100000);
        }
        usleep(10000);
    }
    dev_uninit();
    return 0;
}
